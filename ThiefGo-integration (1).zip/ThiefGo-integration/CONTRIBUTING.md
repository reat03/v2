# CONTRIBUTING

### What it is:
This is essentially the set of rules for contributing apparently, only added it because gitlab said to

When we decide on things such as code conventions I'll add them here

### Please:
- Remember to work on your own branch and then submit merge requests as needed
- Have back-ups of your own work
- If you have questions ask