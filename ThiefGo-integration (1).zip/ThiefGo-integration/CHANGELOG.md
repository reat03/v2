# CHANGELOG

### What for:

This is a changelog for the master branch - please please please add what you have changed whenever you add anything to this branch as it might be useful in figuring out what could have been accidentally deleted later on.

### Ben - 2:20, 15/11/22
- Added Test Bench with the current scripts, libs and assets
- Added a basic server within Test Bench which requires node.js alongside express (can install with npm) to run
- Added a demo file for the presentation
- Added CHANGELOG.md

### Ben - 12:21, 07/02/23
- Just a load of stuff check the TB log for what's changed