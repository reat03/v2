array = [1, 2, "test"]
print(type(array))