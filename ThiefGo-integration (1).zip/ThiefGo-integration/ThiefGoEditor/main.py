import math
import random
import tkinter as tk
from tkinter import Canvas as cv
import json

'''
class PowerUp:
    def __init__(self, x, y, sprite, puType):
        self.x = x
        self.y = y
        self.sprite = sprite
        self.puType = puType
        self.location = puType + " @ (" + str(x) + ", " + str(y) + ")"
        self.type = "Power Up"


class Boss:
    def __init__(self, rX, rY, rW, rH, name, sprite, dSprite, hp, scX, scY, sG, spX, spY, chargeOdds, projFireP,
                 projOdds, pSprite, pGravity, pSpeed, pBounces, pSizeX, pSizeY):
        self.name = name
        self.rX = int(rX)
        self.rY = int(rY)
        self.rW = int(rW)
        self.rH = int(rH)
        self.sprite = sprite
        self.deathSprite = dSprite
        self.health = int(hp)
        self.scaleX = int(scX)
        self.scaleY = int(scY)
        self.scoreGiven = int(sG)
        self.spawnX = int(spX)
        self.spawnY = int(spY)
        self.chargeOdds = int(chargeOdds)
        self.projFirePoint = int(projFireP)
        self.projOdds = int(projOdds)
        self.projSprite = pSprite
        self.projGravity = bool(pGravity)
        self.projSpeed = int(pSpeed)
        self.projBounces = int(pBounces)
        self.projSize = [int(pSizeX), int(pSizeY)]
        self.type = "Boss"
        self.location = ("Boss @ (" + str(spX) + ", " + str(spY) + "), Room @ [(" + str(rX) + ", " + str(rY) + "), (" +
                         str(int(rX) + int(rW)) + ", " + str(int(rY) + int(rH)) + ")]")


class Texture:
    def __init__(self, name, path):
        self.name = name
        self.path = path
        self.location = name + ", " + path
        self.type = "Texture/Sprite"
'''


class Platform:
    def __init__(self, x1, y1, x2, y2, texture):
        self.x1 = x1
        self.y1 = y1
        self.x2 = x2
        self.y2 = y2
        self.location = "[(" + str(x1) + ", " + str(y1) + "), (" + str(x2) + ", " + str(y2) + ")]"
        self.texture = texture
        self.type = "Platform"

'''
class Enemy:
    def __init__(self, sX, sY, pB, scale, sprite, hp, dS, sG):
        self.startX = sX
        self.startY = sY
        self.location = "(" + str(sX) + ", " + str(sY) + ")"
        self.patrolBounds = pB
        self.sprite = sprite
        self.scale = scale
        self.health = hp
        self.dSprite = dS
        self.scoreGiven = sG
        self.type = "RNG Enemy"


class PatrolEnemy:
    def __init__(self, x, y, PB1, PB2, sprite, scale, hp, sG, dSprite):
        self.startX = x
        self.startY = y
        self.PB = [PB1, PB2]
        self.sprite = sprite
        self.scale = scale
        self.hp = hp
        self.scoreGiven = sG
        self.dSprite = dSprite
        self.type = "Patrol Enemy"
        self.location = "Start: (" + str(y) + ", " + str(x) + "), PB: [" + str(PB1) + ", " + str(PB2) + "]"
'''

def ExportJSON():
    totalJSON = {

    }
    allEnemies = {

    }
    allPlats = []
    for plat in platforms:
        platJSON = {
            "x1": plat.x1,
            "y1": plat.y1,
            "x2": plat.x2,
            "y2": plat.y2,
            "texture": plat.texture
        }
        allPlats.append(platJSON)
    totalJSON['platforms'] = allPlats

    '''groundEnemies = []
    for enemy in enemies:
        enemyJSON = {
            "type": enemy.sprite,
            "health": enemy.health,
            "startX": enemy.startX,
            "startY": enemy.startY,
            "endX": enemy.patrolBounds,
            "rngMove": True,
            "scaleX": enemy.scale,
            "scaleY": enemy.scale,
            "deathSprite": enemy.dSprite,
            "scoreGiven": enemy.scoreGiven
        }
        groundEnemies.append(enemyJSON)
    allEnemies['groundEnemies'] = allEnemies

    totalJSON['enemies'] = allEnemies

    bossRoom = {
        "x": boss.rX,
        "y": boss.rY,
        "w": boss.rW,
        "h": boss.rH,
        "boss": {
            "name": boss.name,
            "sprite": boss.sprite,
            "deathSprite": boss.deathSprite,
            "health": boss.health,
            "scaleX": boss.scaleX,
            "scaleY": boss.scaleY,
            "scoreGiven": boss.scoreGiven,
            "spawnX": boss.spawnX,
            "spawnY": boss.spawnY,
            "projectileFirePoint": boss.projFirePoint,
            "projectileOdds": boss.projOdds,
            "projectileType": {
                "projectileSprite": boss.projSprite,
                "gravity": boss.projGravity,
                "speed": boss.projSpeed,
                "bounces": boss.projBounces,
                "size": [
                    boss.projSize[0],
                    boss.projSize[1]
                ]
            },
            "chargeOdds": boss.chargeOdds
        }
    }

    totalJSON['bossRoom'] = bossRoom
    totalJSON['maxTime'] = 300
    totalJSON['bounds'] = {
        "x": 0,
        "y": 0,
        "w": 12800,
        "h": 7200
    }
    print(totalJSON)
    pass'''
    txt = open("JSONExport.txt", 'w')
    txt.write(json.dumps(totalJSON))
    txt.close()


def ImportJSON():
    pass


def AddPlatform(x1, y1, x2, y2, sprite):
    if len(sprite.get()) > 0:
        curPlat = Platform(int(x1.get()), int(y1.get()), int(x2.get()), int(y2.get()), sprite.get())
        platforms.append(curPlat)
    UpdateViewCanvas()
    CreateObjectFrame()
    pass

'''
def AddRNGEnemy(x, y, PB1, sprite, scale, hp, scoreGiven, deathSprite):
    if len(sprite.get()) > 0 and len(deathSprite.get()) > 0:
        curEnemy = Enemy(int(x.get()), int(y.get()), int(PB1.get()), sprite.get(), int(scale.get()), int(hp.get()),
                         int(scoreGiven.get()), deathSprite.get())
        enemies.append(curEnemy)
    UpdateViewCanvas()
    CreateObjectFrame()
    pass


def AddPatrolEnemy(x, y, PB1, PB2, sprite, scale, hp, scoreGiven, deathSprite):
    if len(sprite.get()) > 0 and len(deathSprite.get()) > 0:
        curEnemy = PatrolEnemy(int(x.get()), int(y.get()), int(PB1.get()), int(PB2.get()), sprite.get(), int(scale.get()),
                               int(hp.get()), int(scoreGiven.get()), deathSprite.get())
        patrolEnemies.append(curEnemy)
    UpdateViewCanvas()
    CreateObjectFrame()
    pass


def AddBoss(rX, rY, rW, rH, name, sprite, dSprite, hp, scX, scY, sG, spX, spY, chargeOdds, projFireP,
            projOdds, pSprite, pGravity, pSpeed, pBounces, pSizeX, pSizeY):
    global boss
    if len(sprite) > 0 and len(dSprite) > 0 and len(pSprite) > 0 and len(name) > 0:
        boss = Boss(rX, rY, rW, rH, name, sprite, dSprite, hp, scX, scY, sG, spX, spY, chargeOdds, projFireP,
                    projOdds, pSprite, pGravity, pSpeed, pBounces, pSizeX, pSizeY)
        allObjs[3] = boss
    UpdateViewCanvas()
    CreateObjectFrame()


def ShowBossFrame(prevFrame):
    prevFrame.grid_forget()
    tk.Label(bossFrame, text="Options", font=("Arial", 20)).grid(row=0, columnspan=10)

    tk.Label(bossFrame, text="Boss Room Details", font=("Arial", 15)).grid(row=1, columnspan=10)
    bRoomX = tk.Entry(bossFrame, font=("Arial", 10))
    bRoomY = tk.Entry(bossFrame, font=("Arial", 10))
    bRoomW = tk.Entry(bossFrame, font=("Arial", 10))
    bRoomH = tk.Entry(bossFrame, font=("Arial", 10))
    tk.Label(bossFrame, text="X:", font=("Arial", 10)).grid(row=2, column=0)
    bRoomX.grid(row=2, column=1)
    tk.Label(bossFrame, text="Y:", font=("Arial", 10)).grid(row=2, column=2)
    bRoomY.grid(row=2, column=3)
    tk.Label(bossFrame, text="W:", font=("Arial", 10)).grid(row=2, column=4)
    bRoomW.grid(row=2, column=5)
    tk.Label(bossFrame, text="H:", font=("Arial", 10)).grid(row=2, column=6)
    bRoomH.grid(row=2, column=7)
    tk.Label(bossFrame, text="Boss Details", font=("Arial", 15)).grid(row=3, columnspan=10)
    tk.Label(bossFrame, text="N.B. all coordinates and the like should be done as a part of the whole world, not relative to the room",
             font=("Arial", 10)).grid(row=4, columnspan=8)
    bName = tk.Entry(bossFrame, font=("Arial", 10))
    bSprite = tk.Entry(bossFrame, font=("Arial", 10))
    bDSprite = tk.Entry(bossFrame, font=("Arial", 10))
    bHealth = tk.Entry(bossFrame, font=("Arial", 10))
    bScaleX = tk.Entry(bossFrame, font=("Arial", 10))
    bScaleY = tk.Entry(bossFrame, font=("Arial", 10))
    bScoreGiven = tk.Entry(bossFrame, font=("Arial", 10))
    bSpawnX = tk.Entry(bossFrame, font=("Arial", 10))
    bSpawnY = tk.Entry(bossFrame, font=("Arial", 10))
    bProjFirePoint = tk.Entry(bossFrame, font=("Arial", 10))
    bProjOdds = tk.Entry(bossFrame, font=("Arial", 10))
    bChargeOdds = tk.Entry(bossFrame, font=("Arial", 10))

    tk.Label(bossFrame, text="Name:", font=("Arial", 10)).grid(row=5, column=0)
    bName.grid(row=5, column=1)
    tk.Label(bossFrame, text="Sprite:", font=("Arial", 10)).grid(row=5, column=2)
    bSprite.grid(row=5, column=3)
    tk.Label(bossFrame, text="Death Sprite:", font=("Arial", 10)).grid(row=5, column=4)
    bDSprite.grid(row=5, column=5)
    tk.Label(bossFrame, text="HP:", font=("Arial", 10)).grid(row=5, column=6)
    bHealth.grid(row=5, column=7)

    tk.Label(bossFrame, text="Scale X:", font=("Arial", 10)).grid(row=6, column=0)
    bScaleX.grid(row=6, column=1)
    tk.Label(bossFrame, text="Scale Y:", font=("Arial", 10)).grid(row=6, column=2)
    bScaleY.grid(row=6, column=3)
    tk.Label(bossFrame, text="Spawn X:", font=("Arial", 10)).grid(row=6, column=4)
    bSpawnX.grid(row=6, column=5)
    tk.Label(bossFrame, text="Spawn Y:", font=("Arial", 10)).grid(row=6, column=6)
    bSpawnY.grid(row=6, column=7)

    tk.Label(bossFrame, text="Score Given:", font=("Arial", 10)).grid(row=7, column=0)
    bScoreGiven.grid(row=7, column=1)
    tk.Label(bossFrame, text="Proj Offset:", font=("Arial", 10)).grid(row=7, column=2)
    bProjFirePoint.grid(row=7, column=3)
    tk.Label(bossFrame, text="Proj Odds:", font=("Arial", 10)).grid(row=7, column=4)
    bProjOdds.grid(row=7, column=5)
    tk.Label(bossFrame, text="Charge Odds:", font=("Arial", 10)).grid(row=7, column=6)
    bChargeOdds.grid(row=7, column=7)

    tk.Label(bossFrame, text="N.B. Proj Offset is how much further up the body of the sprite you would like the "
                             "projectile to fire from and the odds are out of 1,000,000 each tick", font=("Arial", 10)).grid(row=8, columnspan=10)
    tk.Label(bossFrame, text="Projectile Details", font=("Arial", 15)).grid(row=9, columnspan=10)

    projSprite = tk.Entry(bossFrame, font=("Arial", 10))
    projGravity = tk.BooleanVar()
    gravityCB = tk.Checkbutton(bossFrame, text="Gravity", font=("Arial", 10), variable=projGravity, onvalue=True, offvalue=False)
    projSpeed = tk.Entry(bossFrame, font=("Arial", 10))
    projBounces = tk.Entry(bossFrame, font=("Arial", 10))
    projW = tk.Entry(bossFrame, font=("Arial", 10))
    projH = tk.Entry(bossFrame, font=("Arial", 10))

    tk.Label(bossFrame, text="Proj Sprite:", font=("Arial", 10)).grid(row=10, column=0)
    projSprite.grid(row=10, column=1)
    gravityCB.grid(row=10, column=2, columnspan=2)
    tk.Label(bossFrame, text="Proj Speed:", font=("Arial", 10)).grid(row=10, column=4)
    projSpeed.grid(row=10, column=5)
    tk.Label(bossFrame, text="Proj Bounces:", font=("Arial", 10)).grid(row=11, column=0)
    projBounces.grid(row=11, column=1)
    tk.Label(bossFrame, text="Proj Width:", font=("Arial", 10)).grid(row=11, column=2)
    projW.grid(row=11, column=3)
    tk.Label(bossFrame, text="Proj Height:", font=("Arial", 10)).grid(row=11, column=4)
    projH.grid(row=11, column=5)
    tk.Button(bossFrame, text="Add Boss", font=("Arial", 10), bg='#aaaaaa', width=25,
              command=lambda: AddBoss(bRoomX.get(), bRoomY.get(), bRoomW.get(), bRoomH.get(), bName.get(),
                                      bSprite.get(), bDSprite.get(), bHealth.get(), bScaleX.get(), bScaleY.get(),
                                      bScoreGiven.get(), bSpawnX.get(), bSpawnY.get(), bChargeOdds.get(),
                                      bProjFirePoint.get(), bProjOdds.get(), projSprite.get(), projGravity.get(),
                                      projSpeed.get(), projBounces.get(), projW.get(), projH.get())
              ).grid(row=11, column=6, columnspan=2)

    bossFrame.grid(row=0, column=0)
    pass


def ShowCollectibleFrame():
    pass


def ShowDoorFrame():
    pass
'''

def CreateOptionsSection():
    tk.Label(optionsFrame, text="Options", font=("Arial", 20)).grid(row=0, columnspan=10)

    '''tk.Label(optionsFrame, text="Add Entity", font=("Arial", 15)).grid(row=1, columnspan=10)

    enX = tk.Entry(optionsFrame, font=("Arial", 10))
    enY = tk.Entry(optionsFrame, font=("Arial", 10))
    enSprite = tk.Entry(optionsFrame, font=("Arial", 10))
    enHealth = tk.Entry(optionsFrame, font=("Arial", 10))
    enEndX = tk.Entry(optionsFrame, font=("Arial", 10))
    enPB1 = tk.Entry(optionsFrame, font=("Arial", 10))
    enPB2 = tk.Entry(optionsFrame, font=("Arial", 10))
    enDSprite = tk.Entry(optionsFrame, font=("Arial", 10))
    enScale = tk.Entry(optionsFrame, font=("Arial", 10))
    enScoreGiven = tk.Entry(optionsFrame, font=("Arial", 10))
    enSpeed = tk.Entry(optionsFrame, font=("Arial", 10))

    tk.Label(optionsFrame, text="RNG UB X:", font=("Arial", 10)).grid(row=2, column=0)
    enEndX.grid(row=2, column=1)
    tk.Label(optionsFrame, text="Patrol Bound 1:", font=("Arial", 10)).grid(row=2, column=2)
    enPB1.grid(row=2, column=3)
    tk.Label(optionsFrame, text="Patrol Bound 2:", font=("Arial", 10)).grid(row=2, column=4)
    enPB2.grid(row=2, column=5)
    tk.Label(optionsFrame, text="Death Sprite:", font=("Arial", 10)).grid(row=2, column=6)
    enDSprite.grid(row=2, column=7)
    tk.Label(optionsFrame, text="Scale:", font=("Arial", 10)).grid(row=3, column=0)
    enScale.grid(row=3, column=1)
    tk.Label(optionsFrame, text="Score Given:", font=("Arial", 10)).grid(row=3, column=2)
    enScoreGiven.grid(row=3, column=3)
    tk.Label(optionsFrame, text="Patrol Speed:", font=("Arial", 10)).grid(row=3, column=4)
    enSpeed.grid(row=3, column=5)
    tk.Label(optionsFrame, text="HP:", font=("Arial", 10)).grid(row=3, column=6)
    enHealth.grid(row=3, column=7)
    tk.Label(optionsFrame, text="X:", font=("Arial", 10)).grid(row=4, column=0)
    enX.grid(row=4, column=1)
    tk.Label(optionsFrame, text="Y:", font=("Arial", 10)).grid(row=4, column=2)
    enY.grid(row=4, column=3)
    tk.Label(optionsFrame, text="Sprite:", font=("Arial", 10)).grid(row=4, column=4)
    enSprite.grid(row=4, column=5)

    tk.Button(optionsFrame, text="Add RNG Enemy", font=("Arial", 10), width=25, bg="#aaaaaa",
              # command=lambda: AddRNGEnemy(enX, enY, enEndX, enSprite, enScale, enHealth, enScoreGiven, enDSprite)
              ).grid(row=5, column=0, columnspan=2)
    tk.Button(optionsFrame, text="Add Patrol Enemy", font=("Arial", 10), width=25, bg='#aaaaaa',
              # command=lambda: AddPatrolEnemy(enX, enY, enPB1, enPB2, enSprite, enScale, enHealth, enScoreGiven, enDSprite)
              ).grid(row=5, column=2, columnspan=2)'''

    tk.Label(optionsFrame, text="Add Platform", font=("Arial", 15)).grid(row=6, columnspan=10)
    platX1 = tk.Entry(optionsFrame, font=("Arial", 10))
    platY1 = tk.Entry(optionsFrame, font=("Arial", 10))
    platX2 = tk.Entry(optionsFrame, font=("Arial", 10))
    platY2 = tk.Entry(optionsFrame, font=("Arial", 10))
    platSprite = tk.Entry(optionsFrame, font=("Arial", 10))
    tk.Label(optionsFrame, text="X1:", font=("Arial", 10)).grid(row=7, column=0)
    platX1.grid(row=7, column=1)
    tk.Label(optionsFrame, text="Y1:", font=("Arial", 10)).grid(row=7, column=2)
    platY1.grid(row=7, column=3)
    tk.Label(optionsFrame, text="Sprite:", font=("Arial", 10)).grid(row=7, column=4)
    platSprite.grid(row=7, column=5)
    tk.Label(optionsFrame, text="X2:", font=("Arial", 10)).grid(row=8, column=0)
    platX2.grid(row=8, column=1)
    tk.Label(optionsFrame, text="Y2:", font=("Arial", 10)).grid(row=8, column=2)
    platY2.grid(row=8, column=3)
    tk.Button(optionsFrame, text="Add Platform", font=("Arial", 10), width=25, bg="#aaaaaa",
              command=lambda: AddPlatform(platX1, platY1, platX2, platY2, platSprite)
              ).grid(row=8, column=4, columnspan=2)

    '''
    tk.Button(optionsFrame, text="To Boss Frame", font=("Arial", 10), width=25, bg='#aaaaaa',
              command=lambda: ShowBossFrame(optionsFrame)).grid(row=9, column=0, columnspan=2)
    tk.Button(optionsFrame, text="To Collectible Frame", font=("Arial", 10), width=25, bg='#aaaaaa',
              command=lambda: ShowCollectibleFrame()).grid(row=9, column=2, columnspan=2)
    tk.Button(optionsFrame, text="To Switch/Door Frame", font=("Arial", 10), width=25, bg='#aaaaaa',
              command=lambda: ShowDoorFrame()).grid(row=9, column=2, columnspan=2)
    '''


    optionsFrame.grid(row=0, column=0)
    pass


def UpdateViewCanvas():
    global canvas
    canvas.delete("all")
    for i in range(len(allObjs)):
        if type(allObjs[i]) == list:
            for j in range(len(allObjs[i])):
                print(i, j)
                if i == 0:
                    canvasObject.append(canvas.create_rectangle(math.floor(allObjs[i][j].x1 / 20),
                                                                math.floor(allObjs[i][j].y1 / 20),
                                                                math.floor(allObjs[i][j].x2 / 20),
                                                                math.floor(allObjs[i][j].y2 / 20), fill="green"))
                if i == 1:
                    canvasObject.append(canvas.create_oval(math.floor(allObjs[i][j].startX / 20) - 2,
                                                           math.floor(allObjs[i][j].startY / 20) - 2,
                                                           math.floor(allObjs[i][j].startX / 20) + 2,
                                                           math.floor(allObjs[i][j].startY / 20) + 2, fill="black"))
                if i == 2:
                    canvasObject.append(canvas.create_oval(math.floor(allObjs[i][j].startX / 20) - 2,
                                                           math.floor(allObjs[i][j].startY / 20) - 2,
                                                           math.floor(allObjs[i][j].startX / 20) + 2,
                                                           math.floor(allObjs[i][j].startY / 20) + 2, fill='#0000FF'))
        else:
            if i == 3:
                canvasObject.append(canvas.create_rectangle(math.floor(allObjs[i].rX / 20),
                                                            math.floor(allObjs[i].rY / 20),
                                                            math.floor((allObjs[i].rX + allObjs[i].rW) / 20),
                                                            math.floor((allObjs[i].rY + allObjs[i].rH) / 20),
                                                            fill="red"))
                canvasObject.append(
                    canvas.create_oval(math.floor(allObjs[i].spawnX / 20) - (2 * allObjs[i].scaleX),
                                       math.floor(allObjs[i].spawnY / 20) - (2 * allObjs[i].scaleY),
                                       math.floor(allObjs[i].spawnX / 20) + (2 * allObjs[i].scaleX),
                                       math.floor(allObjs[i].spawnY / 20) + (2 * allObjs[i].scaleY),
                                       fill='#FFA500'))

    pass


def CreateViewCanvas():
    viewFrame.grid(row=1, column=0)
    pass


def RemoveItem(item):
    global boss
    '''if item == boss:
        boss = Boss
        allObjs[3] = Boss
    else:'''
    for array in allObjs:
        if item in array:
            array.remove(item)
    CreateObjectFrame()
    UpdateViewCanvas()
    pass


def CreateObjectFrame():
    for widget in objectFrame.winfo_children():  # Deletes all previous children of the options menu
        widget.destroy()
    iteration = 0
    for array in allObjs:
        if type(array) == list:
            for item in array:
                tk.Label(objectFrame, text=item.type, font=("Arial", 10)).grid(row=iteration, column=0)
                tk.Label(objectFrame, text="Location: " + item.location, font=("Arial", 10)).grid(row=iteration, column=1)
                tk.Button(objectFrame, text="Remove", font=("Arial", 10), bg="#aaaaaa", command=lambda: RemoveItem(item)
                          ).grid(row=iteration, column=10)
                iteration += 1
        '''elif type(array) == Boss:
            tk.Label(objectFrame, text=array.type, font=("Arial", 10)).grid(row=iteration, column=0)
            tk.Label(objectFrame, text=array.location, font=("Arial", 10)).grid(row=iteration, column=1)
            tk.Button(objectFrame, text="Remove", font=("Arial", 10), bg='#aaaaaa', command=lambda: RemoveItem(array)
                      ).grid(row=iteration, column=10)'''
    objectFrame.grid(row=0, rowspan=2, column=1)
    pass


def Main():
    CreateOptionsSection()
    CreateViewCanvas()
    CreateObjectFrame()
    pass


if __name__ == '__main__':
    window = tk.Tk()
    window.title("ThiefGo Level Editor")
    viewFrame = tk.Frame(window)
    optionsFrame = tk.Frame(window)
    objectFrame = tk.Frame(window)
    bossFrame = tk.Frame(window)
    collectibleFrame = tk.Frame(window)
    doorFrame = tk.Frame(window)
    canvas = cv(viewFrame, width=640, height=360, bg='#add8e6')
    canvas.grid(column=0, row=0, columnspan=2)
    tk.Button(viewFrame, text="Export", font=("Arial", 10), bg='#aaaaaa', command=lambda: ExportJSON()).grid(row=1, column=0)
    tk.Button(viewFrame, text="Import", font=("Arial", 10), bg='#aaaaaa', command=lambda: ImportJSON()).grid(row=1, column=1)

    refList = [1, 2, "test"]
    allObjs = []
    platforms = []
    enemies = []
    patrolEnemies = []
    canvasObject = []
    # boss = Boss
    allObjs.append(platforms)
    allObjs.append(enemies)
    allObjs.append(patrolEnemies)
    # allObjs.append(boss)

    Main()

    window.mainloop()

''' 
Tools needed:
- Platform Place
- Enemy Place
- Boss Room Draw
- Boss Door Placement
- Switch + Door Placement
- Delete
'''
