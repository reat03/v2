# Thief Go README

### What it is:
This is the team project done for the COMP10120 module. We plan to do a platformer game with a few different features.

### Minimum Viable Product (MVP):
- Single-player
- Login
- Register
- Some accessibility settings
- Multiple levels
- Full sprite and graphics support

### Other features we would like to include:

- Multiplayer support - collaborative
- Player preferences that can be saved
- Music
- Visual customisation - i.e. skins
- Some NPCs that just add to the world somewhat
- Statistics tracking, e.g. time/score for the levels

### Members and their jobs:

| Member   | Role                                    |
|----------|-----------------------------------------|
| Spencer  | Networking & Database Back-end          |
| Raghad   | Menus and Database                      |
| Ghayadah | Level Map Design                        |
| Ben      | Game Mechanics Design & Implementation  |
| Dawei    | Level Design & Implementation           |
| Nimmi    | Level Design & Implementation           |

### Requirements:

Node.js for the test bench to run, with express as the server, and install phaser with npm just in case. N.B. this is just for the test bench as otherwise the html doesn't load the scripts properly due to some phaser oddities. This won't be the case when it is uploaded onto a proper web server.


