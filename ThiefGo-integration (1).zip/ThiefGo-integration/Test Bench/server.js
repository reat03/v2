// Just treat this a black box

const express = require('express');
const path = require('path');

const app = express();
const port = 3000 || proocess.env.PORT;

app.use('/audio', express.static(__dirname + '/audio'));
app.use('/scripts', express.static(__dirname + '/scripts'));
app.use('/libs', express.static(__dirname + '/libs'));
app.use('/assets', express.static(__dirname + '/assets'));
app.use('/levels', express.static(__dirname + '/levels'));
app.use('/pages', express.static(__dirname + '/pages'));
app.use(express.static('public'));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/homePage.html'));
});

app.get('/home', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/homePage.html'));
});

app.get('/aboutUs', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/aboutUs.html'));
});

app.get('/aboutGame', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/aboutGame.html'));
});

app.get('/register', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/registerPage.html'));
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/loginPage.html'));
});

app.get('/play', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/playPage.html'));
});

app.get('/account', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/account.html'));
});

app.get('/contactUs', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/contactUs.html'));
});

app.get('/terms', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/terms.html'));
});

app.get('/policy', (req, res) => {
    res.sendFile(path.join(__dirname, 'pages/privacyPolicy.html'));
});

app.listen(port);
console.log('Server started at http://localhost:' + port);