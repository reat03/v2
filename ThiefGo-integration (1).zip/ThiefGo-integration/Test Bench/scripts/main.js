import * as lvl0 from "./level0.js";
import * as HUD from "../libs/HUD.js";
import * as bLvl from "./bossLevel.js";
import * as tLvl from "./levelTemplate.js";
import * as dthS from "./deathScreen.js";
import * as lmap from "./levelsmap.js";

var config = {
    type: Phaser.AUTO,
    width: 1280,
    height: 720,
    parent: 'game-frame',
    backgroundColor: 0x87CEEB,
    scene: [lmap.levelsmap, tLvl.levelTemplate, bLvl.bossLevel, HUD.HUD, dthS.deathScreen],
    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 700 },
            debug: false
        }
    },
    fps: 60
}

var game = new Phaser.Game(config);