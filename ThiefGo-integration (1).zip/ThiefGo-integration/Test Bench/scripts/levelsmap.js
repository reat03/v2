import * as levelData from "../levels/levelJSONs.js";
import * as objs from "../libs/objects.js";
import * as mobs from "../libs/enemies.js";
import * as plyr from "../libs/player.js";
import eventsCentre from "../libs/EventsCentre.js";
import * as spwn from "../libs/spawners.js";
import * as door from "../libs/door.js";
import * as swch from "../libs/switch.js";
import * as powr from "../libs/powerup.js";
import * as boss from "../libs/boss.js";
import * as bsdr from "../libs/bossdoor.js";
import * as goal from "../libs/goalItem.js";
import { Projectile } from "../libs/projectiles.js";
import { level1 } from "./level1.js";
// The above importants all the required libraries we need

/* 
The entire project is based in scenes and each scene has 4 main functions, in order of execution:
 - init
 - preload
 - create
 - update (time, delta) [called each frame]
time is the internal clock of the program
delta is the time since the last call

The scenes are named through the super() call in the constructor and that is the only part that is required.
Constructors are required for the definition of all this.varName variables as they cannot be defined outside of this.

The most important part of this template is the fact that it is all adaptable and can be changed for any possible level with not much of an issue

Things to change:
 - Class name
 - levelName (at the top of the constuctor)
 - this.lvlData = levelData.level
N.B. Might not be an exhaustive list 
*/
export class levelsmap extends Phaser.Scene { 
     // N.B. class name must be same as the script name
      //cursors: Phaser.Types.Input.keyboard.cursorsKeys
    constructor () {
        let levelName = "maplevels";
        super(levelName);

        this.lvlName = levelName;
        this.lvlData = levelData.BossLevel;  // Put to the correct variable name

        this.platforms;  // Ready for the static group
        this.spawnerPhys;

        this.enemies = [];  // Each individual list of enemies, spawners, doors and switches
        this.spawners = [];
        this.doors = [];
        this.switches = [];
        this.projectiles = [];
        this.powerUps = [];
        this.bossDoors = [];
        this.collectibles = [];

        this.goalItem;

        this.boss;
        this.bRoomBounds;
        this.bossDefeated = false;
        this.inBoss = false;  // Stores whether the player is in a boss fight

        this.clock = 0;  // Sets the clock to 0
        this.frameTime = 0;  // Stores the time for each frame
        this.maxTime = this.lvlData.maxTime;
        this.prevTime = this.maxTime;
        this.stopFunction = false;
        const speed = 100;

        this.player;
        this.cursors;  // Sets it up to be ready to receive inputs
        this.animations = [];

        this.allObjs = [];  // A list of all objects that need collisions
    }

    init () {
        // Nothing needed in here for a template
    }

    preload () {
       this.cursors = this.input.keyboard.createCursorKeys()
       this.load.tilemapCSV('map', 'assets/finmap/mapcsv_level.csv');
       
       this.load.image('tiles', 'assets/finmap/background.png');

        
       this.load.atlas('fox', 'assets/spritesheet.png','assets/spritesheet.json');
       this.load.image('button', 'assets/button.png');


        
 
    }

    create () {

        console.log(this.cache.tilemap.entries)
        
        this.cursors = this.input.keyboard.createCursorKeys()
        const map = this.make.tilemap({key:'map', tileWidth: 12, tileHeight: 12});
        const tileset = map.addTilesetImage('tiles');
        const backgroundLayer = map.createLayer(0,tileset ,0,0);
        backgroundLayer.setCollisionByProperty({collides: true});
        const debugGraphics = this.add.graphics().setAlpha(0.5);
        backgroundLayer.renderDebug(debugGraphics,{
            tileColor: null,
            collidingTileColor: new Phaser.Display.Color(243, 234, 48, 255),
            faceColor: new Phaser.Display.Color(40, 39, 37, 255)
        })

        //buttons for each lvl 
        const button1 = this.add.image(260, 340 , 'button').setInteractive().on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, ()=>{
            console.log(this.scene.start('levelName'))
        })
        this.add.text(258, 335, '1', {font: '"Press Start 2P"' , color:'#fff' , fontSize:'10px'});
        const button2 = this.add.image(393, 260 , 'button').setInteractive().on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, ()=>{
            console.log(this.scene.start('level-2'))
        })
        this.add.text(391, 255, '2', {font: '"Press Start 2P"' , color:'#fff' , fontSize:'12px'});
        const button3 = this.add.image(650, 350 , 'button').setInteractive().on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, ()=>{
            console.log(this.scene.start('level-3'))
        })
        this.add.text(647, 345, '3', {font: '"Press Start 2P"' , color:'#fff' , fontSize:'10px'});
        const button4 = this.add.image(770, 425 , 'button').setInteractive().on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, ()=>{
            console.log(this.scene.start('level-4'))
        })
        this.add.text(767, 420, '4', {font: '"Press Start 2P"' , color:'#fff' , fontSize:'10px'});
        const button5 = this.add.image(900, 520 , 'button').setInteractive().on(Phaser.Input.Events.GAMEOBJECT_POINTER_DOWN, ()=>{
            console.log(this.scene.start('level-5'))
        })
        this.add.text(897, 515, '5', {font: '"Press Start 2P"' , color:'#fff' , fontSize:'10px'});

        this.fox = this.physics.add.sprite(280, 275, 'fox', '0.png');

        //change the size of the fox 
        this.fox.setDisplaySize(this.fox.width = 30, this.fox.height= 25);
        this.fox.body.setAllowGravity(false);
        //create the animation for running 

        this.anims.create({
            key: 'fox-0',
            frames:[{ key:'fox', frame:'0.png'}]

        })
        this.anims.create({
            key: 'fox-run',
            frames: this.anims.generateFrameNames('fox', { start: 1, end:7, suffix:'.png'}),
            repeat: -1,
            frameRate: 20

        })
        this.anims.create({
            key: 'fox-run-left',
            frames: this.anims.generateFrameNames('fox', { start: 0, end:7,prefix:'r' ,suffix:'.png'}),
            repeat: -1,
            frameRate: 20

        })


        this.anims.create({
            key: 'fox-stand',
            frames: this.anims.generateFrameNames('fox', { start: 0, end:4,prefix:'fox' ,suffix:'.png'}),
            repeat: -1,
            frameRate: 20

        })


       this.cameras.main.startFollow(this.fox, true);

 
  
    }

    update () {
        // This function is included in phaser and will be called every frame
        // time is the total time in ms the game has been running
        // delta is the timer difference in ms between this frame and the last
        //this.fox.play('fox-stand')
        if(this.cursors.up.isDown ) {
            this.fox.setVelocityY(-160);
            this.fox.anims.play('fox-run', true);

        }else if (this.cursors.down.isDown){
            this.fox.setVelocityY(160);
            this.fox.anims.play('fox-run', true);


        }else if (this.cursors.right.isDown){
            this.fox.setVelocityX(160);
            this.fox.anims.play('fox-run', true);
            
            
        }else if (this.cursors.left.isDown) {
            this.fox.setVelocityX(-160);
            this.fox.anims.play('fox-run-left', true);
        }else {
            this.fox.setVelocityY(0);
            this.fox.setVelocityX(0);
            this.fox.anims.play('fox-stand');
        }

        if ((this.cursors.right.isDown || this.cursors.left.isDown) && !(this.cursors.up.isDown || this.cursors.down.isDown)) {
            this.fox.setVelocityY(0);
        }
        
        if (!(this.cursors.right.isDown || this.cursors.left.isDown) && (this.cursors.up.isDown || this.cursors.down.isDown)) {
            this.fox.setVelocityX(0);
        }

    }



}