class menu extends Phaser.Scene {
    constructor () {
        super("bootGame");
    }

    init () {
        //prepare data
    }

    preload () {
        //load into memory
    }

    create () {
        this.add.text(20, 20, "Loading game...");
        this.scene.start("levelName");
    }

    update () {
        //game loop
    }
}