import eventsCentre from "../libs/EventsCentre.js";

export class deathScreen extends Phaser.Scene {
    constructor () {
        super("deathScreen");

        this.MMButton;
        this.RLButton;
        this.lvlName;
    }

    preload () {
        this.load.image("MMI", "./assets/DeathScreen/MainMenuInactive.png");
        this.load.image("MMA", "./assets/DeathScreen/MainMenuActive.png");
        this.load.image("RLI", "./assets/DeathScreen/RestartLevelInactive.png");
        this.load.image("RLA", "./assets/DeathScreen/RestartLevelActive.png");
    }

    create () {
        this.cameras.main.setBackgroundColor('rgba(255, 83, 73, 1)');
    
        this.anims.create({
            key: "MMB",
            frames: [
                {key: "MMA"},
                {key: "MMI"}
            ],
            frameRate: 10,
            repeat: 0
        });

        this.anims.create({
            key: "RLB",
            frames: [
                {key: "RLA"},
                {key: "RLI"}
            ],
            frameRate: 10,
            repeat: 0
        });

        console.log(this.anims.anims.entries);

        let deathMessage = this.add.text(420, 100, "You Died!");
        deathMessage.setFontSize(90);

        this.RLButton = this.add.sprite(640, 300, 'RLI', 1).setInteractive();
        this.RLButton.name = "RL";

        this.MMButton = this.add.sprite(640, 500, 'MMI', 1).setInteractive();
        this.MMButton.name = "MM";

        this.input.on('gameobjectdown', (pointer, button) => {
            console.log("press", button.name);
            if (button.name == "RL") {
                this.RLButton.play("RLB");
            } else {
                this.MMButton.play("MMB");
            }
        });

        this.RLButton.on(Phaser.Animations.Events.ANIMATION_COMPLETE_KEY + "RLB", () => {
            console.log(this.lvlName);
            this.scene.stop(this.lvlName);
            this.scene.start(this.lvlName);
            this.scene.stop("deathScreen");
        });

        this.MMButton.on(Phaser.Animations.Events.ANIMATION_COMPLETE_KEY + "MMB", () => {
            this.scene.stop(this.lvlName);
            this.scene.start("maplevels");
            this.scene.stop("deathScreen");
        });
        
        eventsCentre.on('level-name', (levelName) => {
            this.lvlName = levelName;
        });
    }
}