import * as levelData from "../levels/levelJSONs.js";
import * as objs from "../libs/objects.js";
import * as mobs from "../libs/enemies.js";
import * as plyr from "../libs/player.js";
import eventsCentre from "../libs/EventsCentre.js";
import { Spawner } from "../libs/spawners.js";
import { Door } from "../libs/door.js";
import { Switch } from "../libs/switch.js";
import { Projectile } from "../libs/projectiles.js";
import { Boss } from "../libs/boss.js";

export class bossLevel extends Phaser.Scene {
    
    constructor () {
        super("playGame");
        this.level0Data = levelData.BossLevel;
        this.platforms;
        this.enemies = [];
        this.allObjs = [];
        this.spawners = [];
        this.doors = [];
        this.switches = [];
        this.projectiles = [];
        this.spawnerPhys;
        this.doorPhys;
        this.player;
        this.clock = 0;
        this.cursors;
        this.frameTime = 0;
        this.boss;
        this.bRoomBounds;
        this.bossDefeated = false;
        this.inBoss = false;
    }

    init () {
        //prepare data
    }

    preload () {
        this.level0Data.textures.forEach((elem) => {
            this.load.image(elem.name, elem.path);
        });
    }

    create () {
        this.physics.world.setBounds(this.level0Data.bounds.x, this.level0Data.bounds.y, this.level0Data.bounds.w, this.level0Data.bounds.h);

        //#region platform generation
        this.platforms = this.physics.add.staticGroup();
        this.allObjs.push(this.platforms);

        this.level0Data.platforms.forEach((elem) => {
            new objs.platform(elem.x1, elem.y1, elem.x2, elem.y2, elem.texture, this.platforms);
        });
        //#endregion

        //#region switch generation
        for (let i = 0; i < this.level0Data.switches.length; i++) {
            let doorJSON = this.level0Data.doors[i];
            let doorObj = this.physics.add.staticSprite(doorJSON.x + (doorJSON.w / 2), doorJSON.y + (doorJSON.h / 2), doorJSON.sprite);
            doorObj.scaleX = doorJSON.w / 400;
            doorObj.scaleY = doorJSON.h / 32;
            doorObj.refreshBody();
            this.doors.push(new Door(doorJSON.x, doorJSON.y, doorJSON.w, doorJSON.h, doorObj));

            let switchJSON = this.level0Data.switches[i];
            let tempObj = this.physics.add.staticSprite(switchJSON.x, switchJSON.y, switchJSON.sprite);
            this.switches.push(new Switch(switchJSON.x, switchJSON.y, this.doors[i], switchJSON.sprite, tempObj));
        }

        this.doors.forEach((dr) => {
            this.AddCollisions(dr.obj);
        });

        this.switches.forEach((sw) => {
            this.AddCollisions(sw.obj);
        });

        //#endregion

        //#region enemy spawning
        if (this.level0Data.enemies.length > 0) {
            this.level0Data.enemies.groundEnemies.forEach((elem) => {
                let tempObj = this.physics.add.sprite(elem.startX, elem.startY, elem.type);
                tempObj.scaleX = elem.scaleX;
                tempObj.scaleY = elem.scaleY;
                tempObj.refreshBody();
                this.enemies.push(new mobs.groundEnemy(elem.startX, elem.endX, elem.type, elem.health, elem.deathSprite, elem.scaleX, elem.scaleY, elem.scoreGiven, tempObj));
            });
    
            this.level0Data.enemies.patrolEnemies.forEach((elem) => {
                let tempObj = this.physics.add.sprite(elem.startX, elem.startY, elem.type);
                tempObj.scaleX = elem.scaleX;
                tempObj.scaleY = elem.scaleY;
                tempObj.refreshBody();
                this.enemies.push(new mobs.patrolEnemy(elem.startX, elem.patrolBounds, elem.type, elem.health, elem.deathSprite, elem.scaleX, elem.scaleY, elem.scoreGiven, elem.speed, tempObj));
            });
    
            this.enemies.forEach((mob) => {
                this.AddCollisions(mob.obj);
            });
        }
        
        //#endregion

        //#region spawner creation
        

        if (this.level0Data.enemies.length > 0) {
            this.spawnerPhys = this.physics.add.staticGroup();
            this.allObjs.push(this.spawnerPhys);
            this.level0Data.enemies.spawners.forEach((cage) => {
                this.spawners.push(new Spawner(cage.x, cage.y, cage.odds, cage.sprite, cage.type, cage.patrols, cage.details, this.spawnerPhys));
            });
            this.AddCollisions(this.spawnerPhys);
        };
        
        //#endregion

        //#region boss spawning
        let bossDetails = this.level0Data.bossRoom.boss;
        let tempBossObj = this.physics.add.sprite(bossDetails.spawnX, bossDetails.spawnY, bossDetails.sprite);
        tempBossObj.scaleX = bossDetails.scaleX;
        tempBossObj.scaleY = bossDetails.scaleY;
        tempBossObj.refreshBody();
        this.boss = new Boss(tempBossObj, this.level0Data.bossRoom);

        this.bRoomBounds = {
            "x1": this.level0Data.bossRoom.x,
            "y1": this.level0Data.bossRoom.y,
            "x2": this.level0Data.bossRoom.w + this.level0Data.bossRoom.x,
            "y2": this.level0Data.bossRoom.h + this.level0Data.bossRoom.y
        }

        this.AddCollisions(this.boss.obj);
        //#endregion

        //#region player spawning
        let tempPObjs = this.physics.add.sprite(this.level0Data.player.x, this.level0Data.player.y, this.level0Data.player.sprite);
        this.player = new plyr.Player(tempPObjs, "FoxTest");

        this.player.obj.setFriction(0.8);

        // sets camera up
        this.cameras.main.startFollow(this.player.obj, true, 0.9, 0.9);
        this.cameras.main.setBounds(this.level0Data.bounds.x, this.level0Data.bounds.y, this.level0Data.bounds.w, this.level0Data.bounds.h);

        this.AddCollision(this.player.obj, this.platforms);
        this.AddCollision(this.player.obj, this.doorPhys);
        this.AddCollision(this.player.obj, this.spawnerPhys);

        this.enemies.forEach((elem) => {
            this.physics.add.collider(elem.obj, this.player.obj, () => {
                if (this.player.attacking && this.clock > this.player.collideCooldown) {
                    elem.health--;
                    this.player.obj.setVelocityX(-400);
                    this.player.obj.setVelocityY(-400);
                }
                else if (this.clock > this.player.collideCooldown) {
                    this.player.TakeDamage();
                }
                this.player.collideCooldown = this.clock + 60;
            });
        });

        this.switches.forEach((s) => {
            this.physics.add.collider(s.obj, this.player.obj, () => {
                s.Activate(this);
            });
        });

        this.doors.forEach((d) => {
            this.physics.add.collider(d.obj, this.player.obj);
        });

        this.physics.add.collider(this.player.obj, this.boss.obj, () => {
            if (this.player.collideCooldown <= this.clock) {
                if (this.boss.charging) {
                    this.player.TakeDamage();
                    if (this.boss.obj.body.velocity.x < 0) {
                        this.player.obj.setVelocityX(-800);
                    } else {
                        this.player.obj.setVelocityX(800);
                    }
                    this.player.obj.setVelocityY(-200);
                }
                else if (this.player.attacking) {
                    this.boss.TakeDamage(this.clock);
                    this.player.obj.setVelocityY(-400);
                    if (this.player.obj.body.x < (this.bRoomBounds.x1 + this.bRoomBounds.x2) / 2) {
                        this.player.obj.setVelocityX(-300);
                    } else {
                        this.player.obj.setVelocityX(300);
                    }
                } else {
                    this.player.TakeDamage();
                }
                this.player.collideCooldown = this.clock + 60;
            }
        });

        this.player.obj.setCollideWorldBounds(true);
        this.allObjs.push(this.player.obj);
        //#endregion

        this.cursors = this.input.keyboard.createCursorKeys();

        this.scene.launch("HUD");

        eventsCentre.on('boss-defeated', () => {
            this.bossDefeated = true;
            this.physics.world.setBounds(this.level0Data.bounds.x, this.level0Data.bounds.y, this.level0Data.bounds.w, this.level0Data.bounds.h);
        });
    }

    fixedUpdate () {
        let curEnemyCount = this.enemies.length;

        this.spawners.forEach((cage) => {
            cage.Refresh(this.enemies, this, this.player, this.platforms);
        });
        
        let newEnemyCount = this.enemies.length;

        if (curEnemyCount != newEnemyCount) {
            let elem = this.enemies[this.enemies.length - 1];
            this.physics.add.collider(elem.obj, this.player.obj, () => {
                if (this.player.attacking && this.clock > this.player.collideCooldown) {
                    elem.health--;
                    this.player.obj.setVelocityX(-400);
                    this.player.obj.setVelocityY(-400);
                }
                else if (this.clock > this.player.collideCooldown) {
                    this.player.TakeDamage();
                }
                this.player.collideCooldown = this.clock + 60;
            });
            this.enemies.forEach((mob) => {
                this.physics.add.collider(elem.obj, mob.obj, () => {
                    elem.Turn();
                    mob.Turn();
                });
            });
            this.physics.add.collider(elem.obj, this.platforms);
        }


        let curProjCount = this.projectiles.length;

        this.boss.AICall(this, this.projectiles, this.player, this.clock, this.platforms);

        let newProjCount = this.projectiles.length;

        if (curProjCount != newProjCount) {
            let proj = this.projectiles[this.projectiles.length - 1];
            this.physics.add.collider(proj.obj, this.player.obj, () => {
                if (this.player.collideCooldown <= this.clock) {
                    this.player.TakeDamage();
                    this.player.collideCooldown = this.clock + 60;
                }
                proj.obj.destroy();
            });
            this.physics.add.collider(proj.obj, this.platforms, () => {
                proj.AddBounce();
            });
        }
    }

    update (time, delta) {
        this.frameTime += delta;
        if (this.frameTime >= 16.5) {
            this.frameTime = 0;
            this.fixedUpdate();
        }
        
        if (this.player.obj.body.touching.down && !this.cursors.left.isDown && !this.cursors.right.isDown) {
            this.player.obj.setVelocityX(this.player.obj.body.velocity.x - (this.player.obj.body.velocity.x / 10));
            if (-5 < this.player.obj.body.velocity.x < 5) {
                this.player.obj.setVelocityX(0);
                this.player.obj.setAccelerationX(0);
            }
        }

        if (this.bRoomBounds.x1 <= this.player.obj.body.x && this.player.obj.body.x <= this.bRoomBounds.x2 && this.bRoomBounds.y1 <= this.player.obj.body.y && this.player.obj.body.y <= this.bRoomBounds.y2 && !this.inBoss && !this.bossDefeated) {
            this.physics.world.setBounds(this.bRoomBounds.x1, this.bRoomBounds.y1, this.bRoomBounds.x2 - this.bRoomBounds.x1, this.bRoomBounds.y2 - this.bRoomBounds.y1);
            this.inBoss = true;
            this.boss.active = true;
            this.cameras.main.setBounds(this.bRoomBounds.x1, this.bRoomBounds.y1, this.level0Data.bossRoom.w, this.level0Data.bossRoom.h);
        }

        if (this.inBoss) {
            if (this.boss.health == -1) {
                this.inBoss = false;
                this.cameras.main.setBounds(this.level0Data.bounds.x, this.level0Data.bounds.y, this.level0Data.bounds.w, this.level0Data.bounds.h);
            }
        }

        if (this.cursors.space.isDown) {
            this.player.Jump();
        }

        if (this.cursors.left.isDown) {
            this.player.Move(true);
        }
        else if (this.cursors.right.isDown) {
            this.player.Move(false);
        }

        if (this.clock == this.player.jumpCooldown) {
            this.player.canJump = true
        }
        if (this.player.obj.body.touching.down) {
            this.player.attacking = false;
        }

        this.enemies.forEach((mob) => {
            mob.AICall(this, this.player, this.platforms, this.enemies);
        });

        this.projectiles.forEach((pr) => {
            pr.Refresh();
        });

        this.clock++;
        this.player.clock = this.clock;
    }

    AddCollisions(entity) {
        this.allObjs.forEach((elem) => {
            this.AddCollision(entity, elem);
        });
        this.allObjs.push(entity);
    }

    AddCollision(a, b) {
        this.physics.add.collider(a, b);
    }
}