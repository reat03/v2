import * as levelData from "../levels/levelJSONs.js";
import * as objs from "../libs/objects.js";
import * as mobs from "../libs/enemies.js";
import * as plyr from "../libs/player.js";
import eventsCentre from "../libs/EventsCentre.js";
import * as spwn from "../libs/spawners.js";
import * as door from "../libs/door.js";
import * as swch from "../libs/switch.js";
import * as powr from "../libs/powerup.js";
import * as boss from "../libs/boss.js";
import * as bsdr from "../libs/bossdoor.js";
import * as goal from "../libs/goalItem.js";
// The above importants all the required libraries we need

/* 
The entire project is based in scenes and each scene has 4 main functions, in order of execution:
 - init
 - preload
 - create
 - update (time, delta) [called each frame]
time is the internal clock of the program
delta is the time since the last call

The scenes are named through the super() call in the constructor and that is the only part that is required.
Constructors are required for the definition of all this.varName variables as they cannot be defined outside of this.

The most important part of this template is the fact that it is all adaptable and can be changed for any possible level with not much of an issue

Things to change:
 - Class name
 - levelName (at the top of the constuctor)
 - this.lvlData = levelData.level
N.B. Might not be an exhaustive list 
*/
export class levelTemplate extends Phaser.Scene {  // N.B. class name must be same as the script name
    constructor () {
        let levelName = "levelName";
        super(levelName);

        this.lvlName = levelName;
        this.lvlData = levelData.DemoLevel;  // Put to the correct variable name

        this.platforms;  // Ready for the static group
        this.spawnerPhys;

        this.enemies = [];  // Each individual list of enemies, spawners, doors and switches
        this.spawners = [];
        this.doors = [];
        this.switches = [];
        this.projectiles = [];
        this.powerUps = [];
        this.bossDoors = [];
        this.collectibles = [];

        this.goalItem;

        this.boss;
        this.bRoomBounds;
        this.bossDefeated = false;
        this.inBoss = false;  // Stores whether the player is in a boss fight

        this.clock = 0;  // Sets the clock to 0
        this.frameTime = 0;  // Stores the time for each frame
        this.maxTime = this.lvlData.maxTime;
        this.prevTime = this.maxTime;
        this.stopFunction = false;
        this.prevFrameOnGround = false;

        this.player;
        this.cursors;  // Sets it up to be ready to receive inputs
        this.animations = [];

        this.allObjs = [];  // A list of all objects that need collisions
    }

    init () {
        // Nothing needed in here for a template
    }

    preload () {
        this.lvlData.textures.forEach((elem) => {  // loads all textures - needs to be changed when animation introduced
            this.load.image(elem.name, elem.path);
        });

        // Loads all audio in the JSON
        this.lvlData.audio.forEach((mpeg) => {
            this.load.audio(mpeg.name, [mpeg.mp3, mpeg.ogg]);
        });

        let animIterator = 0;
        this.lvlData.animations.forEach((anim) => {
            let frameIterator = 0;

            let animIString = String(animIterator);

            let curAnimFrames = [];

            anim.frames.forEach((fram) => {
                let frameIstring = String(frameIterator);
                let theString = animIString + "," + frameIstring;
                this.load.image(theString, fram);
                curAnimFrames.push( { key: theString } );
                frameIterator++;
            });

            this.animations.push(curAnimFrames);

            animIterator++;
        });
    }

    create () {
        // Creates animations
        let animIterator = 0;
        this.lvlData.animations.forEach((anim) => {
            this.anims.create({
                key: anim.name,
                frames: this.animations[animIterator],
                frameRate: anim.framerate,
                repeat: anim.repeatValue
            });
            animIterator++;
        });

        // Sets the bounds of the physics world
        this.physics.world.setBounds(this.lvlData.bounds.x, this.lvlData.bounds.y, this.lvlData.bounds.w, this.lvlData.bounds.h);
    
        //#region platform creation
        this.platforms = this.physics.add.staticGroup();  // Adds a set of objects with no physics apart from collision
        this.allObjs.push(this.platforms);  // Adds it to all objects for later
    
        if (this.lvlData.platforms.length > 0)
        {
            this.lvlData.platforms.forEach((elem) => {  // Creates a platform from the lib
                new objs.platform(elem.x1, elem.y1, elem.x2, elem.y2, elem.texture, this.platforms);
            });
        }
        //#endregion

        //#region switch and door creation
        if (this.lvlData.switches.length > 0) {
            for (let i = 0; i < this.lvlData.switches.length; i++) {  // Must use indices to get correct part
                let drJSON = this.lvlData.doors[i];
                let drX = drJSON.x + (drJSON.w / 2);  // Creates objects from the centre outwards so this finds the middle
                let drY = drJSON.y + (drJSON.h / 2);
                let drObj = this.physics.add.staticSprite(drX, drY, drJSON.sprite);
                drObj.scaleX = drJSON.w / 400;  // Using a 400x32px wide sprite
                drObj.scaleY = drJSON.h / 32;
                drObj.refreshBody();  // Reloads it with new settings
                this.doors.push(new door.Door(drJSON.x, drJSON.y, drJSON.w, drJSON.h, drObj));  // Pushes it to the door array
    
                let swJSON = this.lvlData.switches[i];
                let swObj = this.physics.add.staticSprite(swJSON.x, swJSON.y, swJSON.sprite);  // Static sprites are immobile but can still have specific collision interactions
                this.switches.push(new swch.Switch(swJSON.x, swJSON.y, this.doors[i], swJSON.sprite, swObj));
            
                this.doors.forEach((dr) => {  // Adds collisions
                    this.AddCollisions(dr.obj);
                });
        
                this.switches.forEach((sw) => {
                    this.AddCollisions(sw.obj);
                });
            }
        }
        //#endregion

        //#region boss door creation
        if (this.lvlData.bossDoors.length > 0) {
            this.lvlData.bossDoors.forEach((dr) => {
                let doorX = dr.x + (dr.w / 2);
                let doorY = dr.y + (dr.h / 2);
                let drObj = this.physics.add.staticSprite(doorX, doorY, dr.sprite);
                drObj.scaleX = dr.w / 400;
                drObj.scaleY = dr.h / 32;
                drObj.refreshBody();
                this.bossDoors.push(new bsdr.BossDoor(dr.x, dr.y, dr.w, dr.h, drObj));
            });

            this.bossDoors.forEach((dr) => {
                this.AddCollisions(dr.obj);
            });
        }
        //#endregion

        //#region power up spawning
        if (this.lvlData.powerups.length > 0) {
            this.lvlData.powerups.forEach((pu) => {
                let puObj = this.physics.add.sprite(pu.x, pu.y, pu.sprite);
                puObj.scaleX = 0.5;
                puObj.scaleY = 0.5;
                puObj.refreshBody();
                this.powerUps.push(new powr.PowerUp(pu.type, pu.x, pu.y, pu.sprite, puObj));
            });
            
            this.powerUps.forEach((pu) => {
                this.AddCollisions(pu.obj);
            });
        }
        //#endregion
    
        //#region enemy spawning
        if (this.lvlData.enemies.groundEnemies.length > 0) {
            this.lvlData.enemies.groundEnemies.forEach((elem) => {  // Loops through all ground enemies
                let enObj = this.physics.add.sprite(elem.startX, elem.startY, elem.type);
                enObj.scaleX = elem.scaleX;  // Creates the object to spec
                enObj.scaleY = elem.scaleY;
                enObj.refreshBody();
                // Pushes the object to the array
                this.enemies.push(new mobs.groundEnemy(elem.startX, elem.endX, elem.type, elem.health, elem.deathSprite, elem.scaleX, elem.scaleY, elem.scoreGiven, elem.animations, enObj));
            });
        }

        if (this.lvlData.enemies.patrolEnemies.length > 0) {
            this.lvlData.enemies.patrolEnemies.forEach((elem) => {  // Loops
                let enObj = this.physics.add.sprite(elem.startX, elem.startY, elem.type);  // Creates object
                enObj.scaleX = elem.scaleX;
                enObj.scaleY = elem.scaleY;
                enObj.refreshBody();
                // Pushes object
                this.enemies.push(new mobs.patrolEnemy(elem.startX, elem.patrolBounds, elem.type, elem.health, elem.deathSprite, elem.scaleX, elem.scaleY, elem.scoreGiven, elem.speed, elem.animations, enObj));
            });
        }

        if (this.enemies.length > 0) {
            this.enemies.forEach((mob) => {  // Loops through all enemies to add collision
                this.AddCollisions(mob.obj);
            });
        }
        //#endregion
    
        //#region spawner creation
        if (this.lvlData.enemies.spawners.length > 0) {
            this.spawnerPhys = this.physics.add.staticGroup();  // Creates the physics object
    
            this.lvlData.enemies.spawners.forEach((sp) => {  // Loops through all spawners and creates them then adds them to the list
                this.spawners.push(new spwn.Spawner(sp.x, sp.y, sp.odds, sp.sprite, sp.type, sp.patrols, sp.details, this.spawnerPhys));
            });
            //this.AddCollisions(this.spawnerPhys);  // Adds the collisions for the spawnerPhys object
        }
        //#endregion

        //#region boss spawning
        let bossDetails = this.lvlData.bossRoom.boss;  // Creates a temp variable to easily access the boss details from the JSON
        let tempBossObj = this.physics.add.sprite(bossDetails.spawnX, bossDetails.spawnY, bossDetails.sprite);  // Create the game object and instantiates it
        tempBossObj.scaleX = bossDetails.scaleX;  // Sets the scales
        tempBossObj.scaleY = bossDetails.scaleY;
        tempBossObj.refreshBody();  // Refreshes the body - meaning the scale changes take effect
        this.boss = new boss.Boss(tempBossObj, this.lvlData.bossRoom);  // Sets the boss for the level

        this.bRoomBounds = {  // Sets the bounds of the boss room
            "x1": this.lvlData.bossRoom.x,
            "y1": this.lvlData.bossRoom.y,
            "x2": this.lvlData.bossRoom.w + this.lvlData.bossRoom.x,
            "y2": this.lvlData.bossRoom.h + this.lvlData.bossRoom.y
        }

        this.AddCollisions(this.boss.obj);  // Adds all the collisions for the boss object
        //#endregion

        //#region goal spawning
        let goalObj = this.physics.add.sprite(this.lvlData.goalItem.x, this.lvlData.goalItem.y, this.lvlData.goalItem.sprite);
        this.goalItem = new goal.GoalItem(this.lvlData.goalItem.x, this.lvlData.goalItem.y, this.lvlData.goalItem.sprite, this.lvlData.goalItem.nextLevel, goalObj);
        this.AddCollisions(this.goalItem.obj);
        //#endregion

        //#region player spawning
        // Creates the game object and adds the player to the variable
        let plyrObj = this.physics.add.sprite(this.lvlData.player.x, this.lvlData.player.y, this.lvlData.player.sprite);
        this.player = new plyr.Player(plyrObj, this.lvlData.player.sprite, this.lvlData.player.deathSprite);
        
        // Camera setup
        // Sets the main camera for the level to follow the player and sets the bounds to the world bounds
        this.cameras.main.startFollow(this.player.obj, true, 0.9, 0.9);
        this.cameras.main.setBounds(this.lvlData.bounds.x, this.lvlData.bounds.y, this.lvlData.bounds.w, this.lvlData.bounds.h);
        
        // Adds collisions
        this.AddCollision(this.player.obj, this.platforms);
        this.AddCollision(this.player.obj, this.spawnerPhys);

        if (this.enemies.length > 0) {  // Checks if there are any enemies
            this.enemies.forEach((mob) => {  // Adds collision to each enemy
                this.physics.add.collider(mob.obj, this.player.obj, () => {  // This collision causes a function
                    if (this.player.attacking && this.clock > this.player.collideCooldown) {  // Checks if the player is attacking and they can collide
                        let sound = this.sound.add("HitEnemy");
                        sound.play();
                        mob.health--;  // Removes the health of the attacked mob
                        this.player.obj.setVelocityX(-400);
                        this.player.obj.setVelocityY(-400);  // Sets some knockback
                    }
                    else if (this.clock > this.player.collideCooldown) {  // If the player isn't attacking but can collide
                        this.player.TakeDamage();  // The player takes damage
                        let sound = this.sound.add("PlayerDamage");
                        sound.play();
                    }
                    this.player.collideCooldown = this.clock + 60;  // Sets the collision cooldown
                });
            });
        }

        if (this.lvlData.switches.length > 0) {  // Checks if there are any enemies
            this.switches.forEach((sw) => {
                this.physics.add.collider(sw.obj, this.player.obj, () => {
                    let sound = this.sound.add("SwitchPush");
                    sound.play();
                    sw.Activate(this);  // Activates the switch when it collides with the player
                });
            });
    
            this.doors.forEach((dr) => {
                this.physics.add.collider(dr.obj, this.player.obj);  // Adds collision for each door
            });
        };

        if (this.lvlData.bossDoors.length > 0) {
            this.bossDoors.forEach((dr) => {
                this.physics.add.collider(dr.obj, this.player.obj);
            });
        }

        if (this.lvlData.powerups.length > 0) {
            this.powerUps.forEach((pu) => {
                this.physics.add.collider(pu.obj, this.player.obj, () => {
                    let sound = this.sound.add("PickUpHeart");
                    sound.play();
                    pu.PickUp(this);
                });
            });
        }

        this.physics.add.collider(this.player.obj, this.boss.obj, () => {  // Adds the collider
            if (this.player.collideCooldown <= this.clock) {  // Checks if the player can collide
                if (this.boss.charging) {  // Check if the boss is doing a charge attacks
                    if (this.boss.obj.body.velocity.x < 0) {  // Checks the velocity of the player and applies knockback accordingly
                        this.player.obj.setVelocityX(-800);
                    } else {
                        this.player.obj.setVelocityX(800);
                    }
                    this.player.obj.setVelocityY(-200);
                    let sound = this.sound.add("PlayerDamage");
                    sound.play();
                    this.player.TakeDamage();  // Makes the player take damage
                }
                else if (this.player.attacking) {  // If the boss isn't charging but the player is attacking
                    this.boss.TakeDamage(this.clock);  // Get the boss to take damage
                    this.player.obj.setVelocityY(-400);  // Apply the knockback from the successful hit
                    if (this.player.obj.body.x < (this.bRoomBounds.x1 + this.bRoomBounds.x2) / 2) {
                        this.player.obj.setVelocityX(-300);
                    } else {
                        this.player.obj.setVelocityX(300);
                    }
                    let sound = this.sound.add("BossTakeHit");
                    sound.play();
                } else {  // If the player just touches the boss when neither is attacking
                    this.player.TakeDamage();  // The player just takes damage
                }
                this.player.collideCooldown = this.clock + 60  // Sets the collision cooldown
            }
        });

        this.physics.add.collider(this.player.obj, this.goalItem.obj, () => {
            this.player.score += 30000;
            eventsCentre.emit('update-score', this.player.score);
            this.scene.start(this.goalItem.transition);
        });

        this.player.obj.setCollideWorldBounds(true);  // Player can't leave the world
        this.allObjs.push(this.player.obj);  // Adds player to allObjs
        this.player.obj.play(this.lvlData.player.animations[0]);

        this.player.obj.on(Phaser.Animations.Events.ANIMATION_COMPLETE_KEY + 'playerDamage', () => {
            this.player.curPlaying = 0;
            this.player.obj.play("playerIdle");
        });

        this.player.obj.on(Phaser.Animations.Events.ANIMATION_COMPLETE_KEY + 'playerDeath', () => {
            this.scene.launch("deathScreen");
            eventsCentre.emit('level-name', this.lvlName);
        });

        //#endregion

        this.cursors = this.input.keyboard.createCursorKeys();  // Adds basic controls

        this.scene.launch("HUD");  // Adds the HUD

        eventsCentre.emit('update-timer', this.maxTime);

        //#region listeners
        eventsCentre.on('boss-defeated', () => {  // Listens for the boss defeated event
            this.bossDefeated = true;  // Sets the bossDefeated flag to true
            // Resets the world bounds
            this.physics.world.setBounds(this.lvlData.bounds.x, this.lvlData.bounds.y, this.lvlData.bounds.w, this.lvlData.bounds.h);
            
            let sound = this.sound.add("BossDeath");
            sound.play();

            this.bossDoors.forEach((dr) => {
                dr.Open(this);
            });
        });

        eventsCentre.on('player-death', () => {
            this.stopFunction = true;

            let sound = this.sound.add("PlayerDeath");
            sound.play();

            this.allObjs.forEach((obj) => {
                if (obj != this.player.obj) {
                    if (obj == this.platforms) {
                        obj.destroy(true);
                    } else {
                        obj.destroy();
                    }
                }
            });
            this.scene.stop("HUD");
            this.cameras.main.setBackgroundColor('rgba(0, 0, 0, 1');
        });

        eventsCentre.on("add-health", (increase) => {
            for (let i = 0; i < increase; i++) {
                if (this.player.health + 1 <= 5) {
                    this.player.health++;
                }
            }
        });

        eventsCentre.on('remove-heart', () => {
            if (this.boss.active && this.boss.charging) {
                this.boss.StopCharge();
            }
        });
        //#endregion
    }

    fixedUpdate () {
        // While not an included function within phaser, it's important for all realtime dependent code
        // This will run approximately 60 times a second

        let curEnemyCount = this.enemies.length;  // Gets total amount of enemies

        if (this.spawners.length > 0) {
            this.spawners.forEach((sp) => {
                sp.Refresh(this.enemies, this, this.player, this.platforms);  // Calls a refresh on the spawner
            });
        }

        let newEnemyCount = this.enemies.length;  // Gets total amount of enemies currently spawned after the refresh

        if (curEnemyCount != newEnemyCount) {  // Checks if a new mob has spawned
            let mob = this.enemies[this.enemies.length - 1];  // Gets the last mob to be added
            this.physics.add.collider(mob.obj, this.player.obj, () => {
                if (this.player.attacking && this.clock > this.player.collideCooldown) {  // Checks if the player is attacking and they can collide
                    mob.health--;  // Removes the health of the attacked mob
                    this.player.obj.setVelocityX(-400);
                    this.player.obj.setVelocityY(-400);  // Sets some knockback
                }
                else if (this.clock > this.player.collideCooldown) {  // If the player isn't attacking but can collide
                    this.player.TakeDamage();  // The player takes damage
                }
                this.player.collideCooldown = this.clock + 60;  // Sets the collision cooldown
            });

            this.enemies.forEach((en) => {  // For every single enemy it will call this
                this.physics.add.collider(mob.obj, en.obj, () => {  // Adds a collider for the enemies
                    en.Turn();  // If they collide with one another they'll turn
                    mob.Turn();
                });
            });

            this.physics.add.collider(mob.obj, this.platforms);
        }

        let curProjCount = this.projectiles.length;  // Records current projectile number

        // Does a boss AI Call
        let chargeSound = this.sound.add("BossCharge");
        this.boss.AICall(this, this.projectiles, this.player, this.clock, this.platforms, chargeSound);

        // Records the new projectile count
        let newProjCount = this.projectiles.length;

        if (curProjCount != newProjCount) {
            // Sets the new projectile to the latest projectile added to the list
            let proj = this.projectiles[this.projectiles.length - 1];

            // Adds the collision between the projectile and the player
            this.physics.add.collider(proj.obj, this.player.obj, () => {
                if (this.player.collideCooldown <= this.clock) {  // Checks the player can be collided with
                    this.player.TakeDamage();  // Gets the player to take damage
                    this.player.collideCooldown = this.clock + 60;  // Resets the collision cooldown
                }
                proj.obj.destroy();  // Destroys the projectile no matter what
            });

            // Adds the collision between the projectile and the platforms
            this.physics.add.collider(proj.obj, this.platforms, () => {
                proj.AddBounce();  // Records a bounce on the projectile
            });
        }
    }

    update (time, delta) {
        // This function is included in phaser and will be called every frame
        // time is the total time in ms the game has been running
        // delta is the timer difference in ms between this frame and the last

        if (this.stopFunction) {
            this.player.obj.setVelocityX(0);
            this.player.obj.setVelocityY(0);
            if (this.player.curPlaying != 5) {
                this.player.obj.play("playerDeath");
                this.player.curPlaying = 5;
            }
            return;
        }

        if (!this.prevFrameOnGround && this.player.obj.body.touching.down) {
            let sound = this.sound.add("PlayerLand");
            sound.play();
        }
        this.prevFrameOnGround = this.player.obj.body.touching.down;

        this.frameTime += delta;  // Adds the time difference
        if (this.frameTime >= 16.5) {  // Checks if it's been a 60th of a second
            this.frameTime = 0;  // Resets frameTime to 0
            this.fixedUpdate();  // Calls fixedUpdate
        }

        let curTime = this.maxTime - Math.floor(time / 1000);
        if (curTime != this.prevTime) {
            this.prevTime = curTime;
            eventsCentre.emit('update-timer', this.prevTime);
        }

        if (curTime == 0) {
            this.player.Die();
            return;
        }

        // Sets player velocity to 0 if not moving and on the ground, while also decelerating if needed
        if (this.player.obj.body.touching.down && !this.cursors.left.isDown && !this.cursors.right.isDown) {
            // Removes some velocity from the player proportional to the currently velocity at 10% per tick
            this.player.obj.setVelocityX(this.player.obj.body.velocity.x - (this.player.obj.body.velocity.x / 10));
            
            // If the velocity is less than 5 units either way, the player velocity is set to 0
            if (-5 < this.player.obj.body.velocity.x < 5) {
                this.player.obj.setVelocityX(0);
                this.player.obj.setAccelerationX(0);
                if (this.player.curPlaying != 0 && this.player.curPlaying != 4 && this.player.curPlaying != 5) {
                    this.player.obj.play("playerIdle");
                    this.player.curPlaying = 0;
                }
            }
        }

        // Sets the animations if the player is falling or jumping
        if (this.player.obj.body.velocity.y < 0) {
            if (this.player.curPlaying != 2 && this.player.curPlaying != 4 && this.player.curPlaying != 5) {
                this.player.obj.stop();
                this.player.obj.play("playerJump");
                this.player.curPlaying = 2;
            }
        }
        if (this.player.obj.body.velocity.y > 0) {
            if (this.player.curPlaying != 3 && this.player.curPlaying != 4 && this.player.curPlaying != 5) {
                this.player.obj.stop();
                this.player.obj.play("playerLand");
                this.player.curPlaying = 3;
            }
        }

        if (this.player.health == 0) {
            this.player.Die();
        }

        if (this.bRoomBounds.x1 <= this.player.obj.body.x && this.player.obj.body.y <= this.bRoomBounds.x2 &&  // Checks the player is within the x bounds
            this.bRoomBounds.y1 <= this.player.obj.body.y && this.player.obj.body.y <= this.bRoomBounds.y2 &&  // Checks the player is within the y bounds
            !this.inBoss && !this.bossDefeated)  /* Checks the boss is neither active nor been defeated */  {
            /*
            Activates the boss and is only one time only
            This stops unnecessary executions and allows the game to run more smoothly overall 
            */
            // Sets the world bounds to be the boss room
            this.physics.world.setBounds(this.bRoomBounds.x1, this.bRoomBounds.y1, this.bRoomBounds.x2 - this.bRoomBounds.x1, this.bRoomBounds.y2 - this.bRoomBounds.y1);
            this.inBoss = true;  // Sets the inBoss flag to true
            this.boss.active = true;  // Activates the boss
            // Sets the camera bounds
            this.cameras.main.setBounds(this.bRoomBounds.x1, this.bRoomBounds.y1, this.lvlData.bossRoom.w, this.lvlData.bossRoom.h);
        }

        if (this.inBoss) {  // Checks if the boss is active
            if (this.boss.health == -1) {  // One time event
                // Resets the inBoss flag
                this.inBoss = false;
                // Resets camera bounds
                this.cameras.main.setBounds(this.lvlData.bounds.x, this.lvlData.bounds.y, this.lvlData.bounds.w, this.lvlData.bounds.h);
            }
        }

        if (this.cursors.space.isDown) {  // Jumps when space is pressed, logic in the player class
            let sound = this.sound.add("PlayerJump");
            this.player.Jump(sound);
        }

        if (this.cursors.left.isDown) {  // Moves left as true is for "goingLeft"
            this.player.Move(true);
        }
        else if (this.cursors.right.isDown) {  // Moves right
            this.player.Move(false);
        }

        if (this.clock == this.player.jumpCooldown) {  // Tells the player they can jump if enough time elapsed
            this.player.canJump = true
        }

        if (this.player.obj.body.touching.down) {  // Resets the attacking flag if the player touches the ground
            this.player.attacking = false;
        }

        this.enemies.forEach((mob) => {  // Calls the AI each frame
            mob.AICall(this, this.player, this.platforms, this.enemies);
        });

        this.projectiles.forEach((pr) => {
            pr.Refresh();  // Calls for a refresh on the projectile each frame
        });

        this.clock++;  // Increments the clock
        this.player.clock = this.clock;  // Sets the player's internal clock
    }

    AddCollisions(entity) {
        this.allObjs.forEach((obj) => {  // For every object
            this.AddCollision(entity, obj);  // Add regular collision between the entity and each object
        });
        this.allObjs.push(entity);  // Add the entity to the list of objects
    }

    AddCollision(a, b) {  // This function is just to make things easier to read more than anything
        this.physics.add.collider(a, b);
    }
}