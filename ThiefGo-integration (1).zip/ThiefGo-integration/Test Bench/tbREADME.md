# Test Bench README

### Test Bench


As this is just a test bench, many features may be missing. This is solely to be used as a testing area within the repo, so try not to edit it while others are using it. I've included the base scripts that I used for the demo so that people may have a look themselves.

N.B. I will be commenting the scripts to explain each part