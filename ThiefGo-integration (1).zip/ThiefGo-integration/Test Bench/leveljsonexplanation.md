# Level JSON Layout and Object

## Unique Values

### Plain English Name - Data Type and Var Name

### ID - int ID
The ID of the level is just a simple way to help with searching through the level objects. Must be unique and essentially works as a primary key.

### Name - string name
The name of the level is important as it is what is used for the starting and launch of the level. This also needs to be unique, as otherwise it will cause collisions when loading the levels.

### Max Time - int maxTime
The max time is how many seconds are allowed for the level with it counting down to 0. Once hitting 0 it will kill off  the player and end that run of the level.

## Multivar Objects

### Goal Item Details - dict goalItem
This the details for the item that is picked up to end the level.

#### X Position - int x
The horizontal location, in pixels, of where the item will be.

#### Y Position - int y
The vertical location, in pixels, of where the item will be.

#### Sprite - string Sprite
The internal reference name of the sprite to end the level.

#### Next Level Name - string nextLevel
The internal name of the next level, found in the JSON under name, in order to allow for the next level to be loaded.

### Boss Room - dict bossRoom
Contains all the details of the boss situation of the level

#### Horizontal Location - int x
This is the far left point of the boss room.

#### Vertical Location - int y
This is the absolute bottom of the boss room.

#### Width - int w
This is the length of the boss room in pixels, stretching right.

#### Height - int h
This is the height of the boss room in pixels, stretching up.

#### Boss - dict boss
Contains the information about the boss itself.

##### Name - string name
The name of the boss that will appear beneath the boss health bar when fighting the boss.

##### Sprite - string sprite
The name of the sprite that will be displayed before any of the boss' animations play.

##### Death Sprite - string deathSprite
The name of the sprite that will be displayed before the animation starts upon the death of the boss.

##### Animations - dict animations
Each data point is in the form of { string ActionName: string AnimName }. This allows the boss to contain many different actions and easy form of changing it to another animation when creating a new level.
Actions: charge, walk, idle, shoot, death.

##### HP - int health
Simply the number of hits before the boss dies.

##### Scale X - int scaleX
The multiplier for the horizontal size of the image. Recommended to keep at 2 or below otherwise the quality of the image is dropped irreperably.

##### Scale Y - int scaleY
The multiplier for the vertical size of the image. Recommended to keep at 2 or below otherwise the quality of the image is dropped irreperably.

##### Score - int scoreGiven
The score given by the boss to the player upon its death. This makes it easy to edit for whenever is needed - value can go up to almost anything required.

##### Spawn X - int spawnX
The spawnpoint of the boss on the world map, note that it is **not** relative to the boss room location.

##### Spawn Y - int spawnY
The spawnpoint of the boss on the world map, note that it is **not** relative to the boss room location.

##### Projectile Spawn Point - int projectileFirePoint
The y offset from the location of the boss to where the projectiles will appear when they are spawned.

##### Projectile Probability - int projectileOdds
The number is put into a calculation where it is the divider of 1,000,000. The result of the division is then used to compare to an RNG value (between 1 and 1,000,000) to determine whether the boss will fire a projectile.

##### Charge Probability - int chargeOdds
The number is put into a calculation where it is the divider of 1,000,000. The result of the division is then used to compare to an RNG value (between 1 and 1,000,000) to determine what action the boss will charge.

##### Projectile Type - dict projectileType
A dictionary that gives all the details of the projectile to be shot by the boss.  
**Projectile Sprite - string projectileSprite**  
The sprite that is used by the projectile - N.B. no animations or rotations.  
**Gravity - bool gravity**  
The boolean that determines whether or not the projectile is affected by gravity.  
**Speed - int speed**  
The integer determines the speed that the projectile travels at.  
**Bounces - int bounces**  
This integer determines the number of bounces that a projectile is allowed to make before it gets destroyed.  
**Size - int[2] size**  
The size of the projectile, with size[0] being the x width and size[1] being the y height.  

### World Bounds - dict bounds
The dictionary determines the start coordinates then the width and height of the world.

#### Horizontal Start Point - int x
The horizontal start point of the world.

#### Vertical Start Point - int y
The vertical start point of the world.

#### World Width - int w
The width of the world, measured in pixels, stretching right when positive.

#### World Height - int h
The height of the world, measured in pixels. N.B. a positive value goes downwards.

### Player Details - dict player
All the details to do with the player, that can be changed at any rate.

#### Spawn X - int x
The horizontal location that the player starts at on the boot of the level.

#### Spawn Y - int y
The vertical location that the player starts at on the boot of the level.

#### Start Sprite - string sprite
The name of the original sprite the player will use before the animations load.

#### Animations - string[6] animations
There are 6 different animations that the player must be able to play.
- Pos 0 - Idle Animation
- Pos 1 - Run Animation
- Pos 2 - Damage Animation
- Pos 3 - Death Animation
- Pos 4 - Jump Animation
- Pos 5 - Land Animation

### All Textures - dict[] textures
An array of dictionaries that map the textures and load them into the scene.

#### Name - string name
The name of the texture to be referenced within the levels and by the objects.

#### File Path - strirng path
The file path of the image that makes up the texture. Starts at the root directory - in this case "Test Bench".

### All Audio - dict[] audio
An array of dictionaries that map the SFX and load them into the scene. The dictionary has to point to 2 different file types, because Web Audio - the audio engine - requires both an OGG and MP3 in order for it to be applicable to as many machines as possible.

#### Name - string name
The name of the SFX to be referenced within the levels and by the objects.

#### MP3 File Path
The file path for the '.mp3' file. The path starts from the root directory - in this case "Test Bench".

#### OGG File Path
The file path for the '.ogg' file. The path starts from the root directory - in this case "Test Bench".

### All Animations - dict[] animations
Each dictionary within this array contains the details of all the animations that the level needs.

#### Name - string name
The name of the animation is the internal reference to the animation.

#### Base Path - string path
The base path is the folder where all the frames of the animation are, starting at the root directory. e.g. "./assets/FoxRun/".

#### Frame Rate - int framerate
The FPS of the animation, i.e. how fast it runs - higher is faster.

#### Animation Frames - string[] frames
The file path to each of the animation frames. The array can be of varible length as different animations have different lengths. Each path begins at the root directory of the program, in this case "Test Bench".

#### Repetitions - int repeatValue
The number of times the animation will repeat:
-1 means infinite repeats
0 means no repeats
Any other positive value is the number of repeats

### All Platforms - dict[] platforms
Each dictionary contains the top-left coordinate and bottom-right coordinate, as well as the texture.

#### Top-Left X - int x1
The leftmost pixel that the platform touches.

#### Top-Left Y - int y1
The topmost pixel that the platform touches.

#### Bottom-Right X - int x2
The rightmost pixel the platform touches.

#### Bottom-Right Y - int y2
The bottommost pizel the platform touches.

#### Sprite/Texture - string texture
The name of the texture that is used for the platform.

### All Enemies - dict enemies
The main dictionary of all enemies and spawners.

#### RNG Movement Enemies - dict[] groundEnemies

#### Patrol Movement Enemies - dict[] patrolEnemies
The complete list of patrol enemies represented as an array of dictionaries.

##### Start Sprite - string type
The starting sprite and also the type of enemy. The starting sprite is shown before any animations are playing.

##### HP - int health
The amount of hits the enemy can take before it dies.

##### Spawn X - int startX
The x-coordinate that the enemy will spawn at.

##### Spawn Y - int startY
The y-coordinate that the enemy will spawn at.

##### Scale X - int scaleX
The multiplier on the horizontal size of the image. Recommended to not go over 2 as it will reduce the quality of the image massively.

##### Scale Y - int scaleY
The multiplier on the vertical size of the image. Recommended to not go over 2 as it will reduce the quality of the image massively.

##### Death Sprite - string deathSprite
The sprite that will be shown upon the death of the enemy - only shown before any animations are played - less than one frame.

##### Score Given - int scoreGiven
The number of points given to the player upon the death of the enemy.

##### Patrol Bounds - int[2] patrolBounds
2 x-coordinates which the enemy will patrol between, with Pos 0 being the leftmost and Pos 1 the rightmost.

##### Speed - int speed
The integer that determines the speed of the enemy.

##### Enemy Animations - string[2] animations
The array of animations with Pos 0 being the move animation and Pos 1 being the death animation.

#### Enemy Spawners - dict[] spawners
The array of spawners and all their details.

##### Sprite/Type - string type
The name of the sprite that is the first frame before animations play and the type of enemy for easy identification.

##### Position X - int x
The x-coordinate where the spawner exists.

##### Position Y - int y
The y-coordinate where the spawner exists.

##### Sprite - string sprite
The sprite/texture of the spawner.

##### Patrolling - bool patrols
A true/false that determines the type of enemy.

##### Details - dict details
The dictionary of all the details of the enemies.  
**HP - int health**  
The number of hits the enemies that are spawned can take before they die.  
**Spawn X - int spawnX**  
The x location of where the spawned enemies appear.  
**Spawn Y - int spawnY**  
The y location of where the spawned enemies appear.  
**Death Sprite - string deathSprite**  
The sprite that is displayed before the death animations is played.  
**Score Given - int scoreGiven**  
The number of points the player gets when the enemy dies.  
**Patrol Bounds - int[2] patrolBounds**  
The patrol bounds of the spawned enemies, with Pos 0 being the leftmost and Pos1 being the rightmost.  
**Speed - int speed**  
The speed of the enemies that are spawned.  
**Scale X - int scaleX**  
The multiplier for the horizontal size of the image. Shouldn't be above 2, otherwise there's a large chance that the image will be of poor quality.  
**Scale Y - int scaleY**  
The multiplier for the vertical size of the image. Shouldn't be above 2, otherwise there's a large chance that the image will be of poor quality.  
**Animations - string[2] animations**  
The names of the animations with Pos 0 being the movement and Pos 1 being the death animation.  

### All Switches - dict[] switches
The array of dictionaries that create all the switches on the level.

#### Pos X - int x
The x-position of the switch.

#### Pos Y - int y
The y-positiom of the switch.

#### Sprite - string sprite
The internal reference name of the sprite, which will be displayed.

#### ID - int id
The ID number of the switch - used to help match the switches to the correct doors.

### All Doors - dict[] doors
The list of all the doors within the level.

#### Pos X - int x
The x-position of the door.

#### Pos Y - int y
The y-position of the door.

#### Width - int w
The width of the door in pixels, stretching right when positive.

#### Height - int h
The height of the door in pixels. If negative then it stretches up, else it stretches down.

#### Texture - string sprite
The internal reference name of the sprite for the door.

#### ID - int id
The ID number of the switch - used to help match the door to the correct switch.

### Power Ups - dict[] powerUps
The list of all the power ups within the level.

#### Type - string type
The type gives the functionality of the power up for when it's picked up.

#### Pos X - int x
The x-position of the power up.

#### Pos Y - int y
The y-position of the power up.

#### Sprite - string sprite
The internal name of the sprite/texture of the power up.

### Boss Doors - dict[] bossDoors
The list of all doors that open once the boss of the level has been defeated.

#### Pos X - int x
The x-position of the boss door.

#### Pos Y - int y
The y-position of the boss door.

#### Width - int w
The width of the boss door - stretches right when positive.

#### Height - int h
The height of the boss door - stretches up if negative.