# TEST BENCH CHANGELOG

This is where I'll be adding all the changes to the test bench

### 15/11/2022 - 2:30
- Added the base game
- Added movement
- Added platforms
- Added patrol enemies
- Added randomly moving enemies
- Added death swaps for each enemy
- Added the HUD
- Added the health bar
- Added player attacks
- Added mob spawners

### 12/12/2022 - 15:30
- Added camera movement so it follows the player
- Added camera bounds so it won't go out the game world
- Added switches and doors to add interactivity into the game world
- Added functionality to said switches and doors
- Added template script

### 04/01/2023 - 15:45
- Added timer
- Added power up support
- Added health power up
- Updated level template file
- Added HUD support for the health power up
- Added projectiles from the boss
- Added charge move from the boss
- Added AI support for the boss
- Added boss rooms
- Added boss health bar

### 06/01/2023 - 19:00
- Added boss doors
- Added Goal Item
- Started work on a level editor

### 07/02/2023 - 12:30
- Added player animations
- Added basics for boss animations
- Added death screen - WIP
- Probably a load more idk I kinda forgot to update this