<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="tf_beach_tileB" tilewidth="12" tileheight="12" tilecount="4096" columns="64">
 <image source="../theifgo/tf_beach_tileB.png" width="768" height="768"/>
</tileset>
