<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="chian 2" tilewidth="12" tileheight="12" tilecount="1024" columns="32">
 <image source="chian 2.png" width="384" height="384"/>
</tileset>
