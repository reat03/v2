<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="sea" tilewidth="12" tileheight="12" tilecount="4000" columns="80">
 <image source="background.png" width="960" height="600"/>
</tileset>
