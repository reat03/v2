export const DemoLevel = {
    "ID": 2,
    "name": "demoLevel",
    "maxTime": 300,
    "goalItem": {
        "x": 2100,
        "y": 1000,
        "sprite": "artifact",
        "nextLevel": ""
    },
    "bossRoom": {
        "x": 1280,
        "y": 20,
        "w": 1280,
        "h": 720,
        "boss": {
            "name": "Cosmic Beast",
            "sprite": "starCreature",
            "deathSprite": "starCreatureDead",
            "animations": {
                "charge": "starCreatureCharge",
                "walk": "starCreatureMove",
                "idle": "starCreatureIdle",
                "shoot": "",
                "death": "starCreatureDeath"
            },
            "health": 5,
            "scaleX": 1.5,
            "scaleY": 1.5,
            "scoreGiven": 10000,
            "spawnX": 1720,
            "spawnY": 500,
            "projectileFirePoint": 50,
            "projectileOdds": 100000000,
            "chargeOdds": 80,
            "projectileType": {
                "projectileSprite": "fireball",
                "gravity": false,
                "speed": 200,
                "bounces": 0,
                "size": [100, 100]
            }
        }
    },
    "bounds": {
        "x": 0,
        "y": 0,
        "w": 2560,
        "h": 1440
    },
    "player": {
        "x": 150,
        "y": 100,
        "sprite": "FoxTest",
        "animations": [
            "playerIdle",
            "playerRun",
            "playerDamage",
            "playerDeath",
            "playerJump",
            "playerLand"
        ]
    },
    "textures": [
        {
            "name": "starCreatureDead",
            "path": "./assets/StarCreatureDeath/5.png"
        },
        {
            "name": "FoxTest",
            "path": "./assets/FoxTest.png"
        },
        {
            "name": "starCreature",
            "path": "./assets/StarCreatureIdle/0.png"
        },
        {
            "name": "ground",
            "path": "./assets/platform.png"
        },
        {
            "name": "deadMech",
            "path": "./assets/DeadMech.png"
        },
        {
            "name": "fireball",
            "path": "./assets/fireball.png"
        },
        {
            "name": "plusOneHealth",
            "path": "./assets/heartPU.png"
        },
        {
            "name": "porcupineSprite",
            "path": "./assets/PorcupineMove/0.png"
        },
        {
            "name":"heartPU",
            "path": "./assets/heartPU.png"
        },
        {
            "name": "barrel",
            "path": "./assets/barrel.png"
        },
        {
            "name": "button",
            "path": "./assets/buttonTemp.png"
        },
        {
            "name": "door",
            "path": "./assets/door.png"
        }
    ],
    "audio": [
        {
            "name": "BossDeath",
            "mp3": "./audio/BossDeath.mp3",
            "ogg": "./audio/BossDeath.ogg"
        },
        {
            "name": "BossCharge",
            "mp3": "./audio/BossCharge.mp3",
            "ogg": "./audio/BossCharge.ogg"
        },
        {
            "name": "BossTakeHit",
            "mp3": "./audio/BossTakeHit.mp3",
            "ogg": "./audio/BossTakeHit.ogg"
        },
        {
            "name": "BossWalk",
            "mp3": "./audio/BossWalk.mp3",
            "ogg": "./audio/BossWalk.ogg"
        },
        {
            "name": "EnemyDeath",
            "mp3": "./audio/EnemyDeath.mp3",
            "ogg": "./audio/EnemyDeath.ogg"
        },
        {
            "name": "HitEnemy",
            "mp3": "./audio/HitEnemy.mp3",
            "ogg": "./audio/HitEnemy.ogg"
        },
        {
            "name": "PickUpHeart",
            "mp3": "./audio/PickUpHeart.mp3",
            "ogg": "./audio/PickUpHeart.ogg"
        },
        {
            "name": "PlayerDamage",
            "mp3": "./audio/PlayerDamage.mp3",
            "ogg": "./audio/PlayerDamage.ogg"
        },
        {
            "name": "PlayerDeath",
            "mp3": "./audio/PlayerDeath.mp3",
            "ogg": "./audio/PlayerDeath.ogg"
        },
        {
            "name": "PlayerJump",
            "mp3": "./audio/PlayerJump.mp3",
            "ogg": "./audio/PlayerJump.ogg"
        },
        {
            "name": "PlayerLand",
            "mp3": "./audio/PlayerLand.mp3",
            "ogg": "./audio/PlayerLand.ogg"
        },
        {
            "name": "PlayerWalk",
            "mp3": "./audio/PlayerWalk.mp3",
            "ogg": "./audio/PlayerWalk.ogg"
        },
        {
            "name": "SwitchPush",
            "mp3": "./audio/SwitchPush.mp3",
            "ogg": "./audio/SwitchPush.ogg"
        }
    ],
    "animations": [
        {
            "name": "playerIdle",
            "path": "./assets/FoxIdle1/",
            "framerate": 8,
            "frames": [
                "./assets/FoxIdle1/0.png",
                "./assets/FoxIdle1/1.png",
                "./assets/FoxIdle1/2.png",
                "./assets/FoxIdle1/3.png",
                "./assets/FoxIdle1/4.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "playerRun",
            "path": "./assets/FoxRun/",
            "framerate": 10,
            "frames": [
                "./assets/FoxRun/0.png",
                "./assets/FoxRun/1.png",
                "./assets/FoxRun/2.png",
                "./assets/FoxRun/3.png",
                "./assets/FoxRun/4.png",
                "./assets/FoxRun/5.png",
                "./assets/FoxRun/6.png",
                "./assets/FoxRun/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "playerJump",
            "path": "./assets/FoxJump/Up/",
            "framerate": 8,
            "frames": [
                "./assets/FoxJump/Up/3.png",
                "./assets/FoxJump/Up/4.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerLand",
            "path": "./assets/FoxJump/Down/",
            "framerate": 8,
            "frames": [
                "./assets/FoxJump/Down/0.png",
                "./assets/FoxJump/Down/1.png",
                "./assets/FoxJump/Down/2.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerDamage",
            "path": "./assets/FoxDamage/",
            "framerate": 8,
            "frames": [
                "./assets/FoxDamage/0.png",
                "./assets/FoxDamage/1.png",
                "./assets/FoxDamage/2.png",
                "./assets/FoxDamage/3.png",
                "./assets/FoxDamage/4.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerDeath",
            "path": "./assets/FoxDeath/",
            "framerate": 4,
            "frames": [
                "./assets/FoxDeath/0.png",
                "./assets/FoxDeath/1.png",
                "./assets/FoxDeath/2.png",
                "./assets/FoxDeath/3.png",
                "./assets/FoxDeath/4.png",
                "./assets/FoxDeath/5.png",
                "./assets/FoxDeath/6.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "porcupineMove",
            "path": "./assets/PorcupineMove/",
            "framerate": 4,
            "frames": [
                "./assets/PorcupineMove/0.png",
                "./assets/PorcupineMove/1.png",
                "./assets/PorcupineMove/2.png",
                "./assets/PorcupineMove/3.png",
                "./assets/PorcupineMove/4.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "porcupineDeath",
            "path": "./assets/PorcupineDeath/",
            "framerate": 4,
            "frames": [
                "./assets/PorcupineDeath/0.png",
                "./assets/PorcupineDeath/1.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "starCreatureMove",
            "path": "./assets/StarCreatureMove/",
            "framerate": 8,
            "frames": [
                "./assets/StarCreatureMove/0.png",
                "./assets/StarCreatureMove/1.png",
                "./assets/StarCreatureMove/2.png",
                "./assets/StarCreatureMove/3.png",
                "./assets/StarCreatureMove/4.png",
                "./assets/StarCreatureMove/5.png",
                "./assets/StarCreatureMove/6.png",
                "./assets/StarCreatureMove/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "starCreatureIdle",
            "path": "./assets/StarCreatureIdle/",
            "framerate": 8,
            "frames": [
                "./assets/StarCreatureIdle/0.png",
                "./assets/StarCreatureIdle/1.png",
                "./assets/StarCreatureIdle/2.png",
                "./assets/StarCreatureIdle/3.png",
                "./assets/StarCreatureIdle/4.png",
                "./assets/StarCreatureIdle/5.png",
                "./assets/StarCreatureIdle/6.png",
                "./assets/StarCreatureIdle/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "starCreatureCharge",
            "path": "./assets/StarCreatureCharge/",
            "framerate": 16,
            "frames": [
                "./assets/StarCreatureCharge/0.png",
                "./assets/StarCreatureCharge/1.png",
                "./assets/StarCreatureCharge/2.png",
                "./assets/StarCreatureCharge/3.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "starCreatureDeath",
            "path": "./assets/StarCreatureDeath/",
            "framerate": 6,
            "frames": [
                "./assets/StarCreatureDeath/0.png",
                "./assets/StarCreatureDeath/1.png",
                "./assets/StarCreatureDeath/2.png",
                "./assets/StarCreatureDeath/3.png",
                "./assets/StarCreatureDeath/4.png",
                "./assets/StarCreatureDeath/5.png"
            ],
            "repeatValue": 0
        }
    ],
    "platforms": [
        {
            "x1": 1260, 
            "y1": 100, 
            "x2": 1280, 
            "y2": 600, 
            "texture": "ground"
        }, 
        {
            "x1": 1260, 
            "y1": 720, 
            "x2": 1280, 
            "y2": 1320, 
            "texture": "ground"
        }, 
        {
            "x1": 0, 
            "y1": 1420, 
            "x2": 2560, 
            "y2": 1440, 
            "texture": "ground"
        }, 
        {
            "x1": 0, 
            "y1": 720, 
            "x2": 580, 
            "y2": 740, 
            "texture": "ground"
        }, 
        {
            "x1": 700, 
            "y1": 720, 
            "x2": 2560, 
            "y2": 740, 
            "texture": "ground"
        }, 
        {
            "x1": 100, 
            "y1": 240, 
            "x2": 300, 
            "y2": 260, 
            "texture": "ground"
        }, 
        {
            "x1": 550, 
            "y1": 340, 
            "x2": 650, 
            "y2": 360, 
            "texture": "ground"
        }, 
        {
            "x1": 460, 
            "y1": 420, 
            "x2": 580, 
            "y2": 440, 
            "texture": "ground"
        }, 
        {
            "x1": 240, 
            "y1": 520, 
            "x2": 460, 
            "y2": 540, 
            "texture": "ground"
        }, 
        {
            "x1": 100, 
            "y1": 620, 
            "x2": 250, 
            "y2": 640, 
            "texture": "ground"
        }, 
        {
            "x1": 560, 
            "y1": 820, 
            "x2": 700, 
            "y2": 840, 
            "texture": "ground"
        }, 
        {
            "x1": 690, 
            "y1": 900, 
            "x2": 810, 
            "y2": 920, 
            "texture": "ground"
        }, 
        {
            "x1": 450, 
            "y1": 980, 
            "x2": 600, 
            "y2": 1000, 
            "texture": "ground"
        }, 
        {
            "x1": 250, 
            "y1": 1040, 
            "x2": 400, 
            "y2": 1060, 
            "texture": "ground"
        }, 
        {
            "x1": 500, 
            "y1": 1140, 
            "x2": 650, 
            "y2": 1160, 
            "texture": "ground"
        }, 
        {
            "x1": 800, 
            "y1": 1120, 
            "x2": 950, 
            "y2": 1140, 
            "texture": "ground"
        }, 
        {
            "x1": 1050, 
            "y1": 1200, 
            "x2": 1200, 
            "y2": 1220, 
            "texture": "ground"
        }, 
        {
            "x1": 950, 
            "y1": 1280, 
            "x2": 1100, 
            "y2": 1300, 
            "texture": "ground"
        }, 
        {
            "x1": 750, 
            "y1": 1340, 
            "x2": 900, 
            "y2": 1360, 
            "texture": "ground"
        }, 
        {
            "x1": 50, 
            "y1": 1340, 
            "x2": 400, 
            "y2": 1360, 
            "texture": "ground"
        }, 
        {
            "x1": 1400, 
            "y1": 1340, 
            "x2": 1600, 
            "y2": 1360, 
            "texture": "ground"
        }, 
        {
            "x1": 1575, 
            "y1": 1260, 
            "x2": 1690, 
            "y2": 1280, 
            "texture": "ground"
        }, 
        {
            "x1": 1690, 
            "y1": 1180,
            "x2": 1800, 
            "y2": 1200, 
            "texture": "ground"
        }, 
        {
            "x1": 2200, 
            "y1": 1300, 
            "x2": 2300, 
            "y2": 1320, 
            "texture": "ground"
        }, 
        {
            "x1": 2300, 
            "y1": 1220, 
            "x2": 2400, 
            "y2": 1240, 
            "texture": "ground"
        }, 
        {
            "x1": 2400, 
            "y1": 1140, 
            "x2": 2500, 
            "y2": 1160, 
            "texture": "ground"
        }, 
        {
            "x1": 2500, 
            "y1": 1040, 
            "x2": 2560, 
            "y2": 1060, 
            "texture": "ground"
        }, 
        {
            "x1": 2000, 
            "y1": 1040, 
            "x2": 2200, 
            "y2": 1060, 
            "texture": "ground"
        }
    ],
    "enemies": {
        "groundEnemies": [

        ],
        "patrolEnemies": [
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 600,
                "startY": 300,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    550,
                    650
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 300,
                "startY": 500,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    240,
                    460
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 200,
                "startY": 600,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    0,
                    580
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 300,
                "startY": 1020,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    250,
                    400
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 1100,
                "startY": 1180,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    1050,
                    1200
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 1500,
                "startY": 1320,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    1400,
                    1600
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 2530,
                "startY": 1020,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    2500,
                    2560
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            },
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 2250,
                "startY": 1220,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    2200,
                    2300
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            }
        ],
        "spawners": [
            {
                "type": "porcupineSprite",
                "x": 600,
                "y": 1180,
                "sprite": "barrel",
                "patrols": true,
                "details": {
                    "health": 1,
                    "spawnX": 600,
                    "spawnY": 1200,
                    "deathSprite": "porcupineSprite",
                    "scoreGiven": 50,
                    "patrolBounds": [
                        300,
                        900
                    ],
                    "speed": 100,
                    "scaleX": 1,
                    "scaleY": 1,
                    "animations": [
                        "porcupineMove",
                        "porcupineDeath"
                    ]
                }
            }
        ]
    },
    "switches": [
        {
            "x": 100,
            "y": 1320,
            "sprite": "button",
            "id": 0
        }
    ],
    "doors": [
        {
            "x": 1260,
            "y": 720,
            "w": 20,
            "h": -120,
            "sprite": "door",
            "id": 0
        }
    ],
    "powerups": [
        {
            "type": "health+1",
            "x": 1400,
            "y": 450,
            "sprite": "plusOneHealth"
        },
        {
            "type": "health+1",
            "x": 2440,
            "y": 450,
            "sprite": "plusOneHealth"
        },
        {
            "type": "health+1",
            "x": 1920,
            "y": 450,
            "sprite": "plusOneHealth"
        }
    ],
    "bossDoors": [
        {
            "x": 1260,
            "y": 1420,
            "w": 20,
            "h": -120,
            "sprite": "door"
        }
    ],
}

export const BossLevel = {
    "ID": 1,
    "name": "bossTest",
    "maxTime": 300, // In seconds
    "goalItem": {
        "x": 2000,
        "y": 600,
        "sprite": "fireball",
        "nextLevel": ""
    },
    "bossRoom": {
        "x": 1000,
        "y": 0,
        "w": 1280,
        "h": 720,
        "boss": {
            "name": "Comet Beast",
            "sprite": "starCreature",
            "deathSprite": "starCreatureDead",
            "animations": {
                "charge": "starCreatureCharge",
                "walk": "starCreatureMove",
                "idle": "starCreatureIdle",
                "shoot": "",
                "death": "starCreatureDeath"
            },
            "health": 5,
            "scaleX": 1,
            "scaleY": 1,
            "scoreGiven": 10000,
            "spawnX": 1000,
            "spawnY": 500,
            "projectileFirePoint": 50,  // How many pixels up the sprite you would like the projectiles to fire from
            "projectileOdds": 60,  // Will be one over that number
            "projectileType": {
                "projectileSprite": "fireball",
                "gravity": false,
                "speed": 200,
                "bounces": 0,
                "size": [100, 100]  // Width and height in pixels - will not rotate
            },
            "chargeOdds": 120
        }
    },
    "bounds": {
        "x": 0,
        "y": 0,
        "w": 3000,
        "h": 720
    },
    "player": {
        "x": 40,
        "y": 300,
        "sprite": "FoxTest",  // This is required for the first spawn of the player
        "animations": [  // First animation will be the idle animation
            "playerIdle",
            "playerRun"
        ],
        "atlas": "" //if required
    },
    "textures": [
        {
            "name": "starCreatureDead",
            "path": "./assets/StarCreatureDeath/5.png"
        },
        {
            "name": "FoxTest",
            "path": "./assets/FoxTest.png"
        },
        {
            "name": "starCreature",
            "path": "./assets/StarCreatureIdle/0.png"
        },
        {
            "name": "ground",
            "path": "./assets/platform.png"
        },
        {
            "name": "deadMech",
            "path": "./assets/DeadMech.png"
        },
        {
            "name": "fireball",
            "path": "./assets/fireball.png"
        },
        {
            "name": "plusOneHealth",
            "path": "./assets/heartPU.png"
        },
        {
            "name": "porcupineSprite",
            "path": "./assets/PorcupineMove/0.png"
        }
    ],
    "audio": [
        {
            "name": "BossDeath",
            "mp3": "./audio/BossDeath.mp3",
            "ogg": "./audio/BossDeath.ogg"
        },
        {
            "name": "BossCharge",
            "mp3": "./audio/BossCharge.mp3",
            "ogg": "./audio/BossCharge.ogg"
        },
        {
            "name": "BossTakeHit",
            "mp3": "./audio/BossTakeHit.mp3",
            "ogg": "./audio/BossTakeHit.ogg"
        },
        {
            "name": "BossWalk",
            "mp3": "./audio/BossWalk.mp3",
            "ogg": "./audio/BossWalk.ogg"
        },
        {
            "name": "EnemyDeath",
            "mp3": "./audio/EnemyDeath.mp3",
            "ogg": "./audio/EnemyDeath.ogg"
        },
        {
            "name": "HitEnemy",
            "mp3": "./audio/HitEnemy.mp3",
            "ogg": "./audio/HitEnemy.ogg"
        },
        {
            "name": "PickUpHeart",
            "mp3": "./audio/PickUpHeart.mp3",
            "ogg": "./audio/PickUpHeart.ogg"
        },
        {
            "name": "PlayerDamage",
            "mp3": "./audio/PlayerDamage.mp3",
            "ogg": "./audio/PlayerDamage.ogg"
        },
        {
            "name": "PlayerDeath",
            "mp3": "./audio/PlayerDeath.mp3",
            "ogg": "./audio/PlayerDeath.ogg"
        },
        {
            "name": "PlayerJump",
            "mp3": "./audio/PlayerJump.mp3",
            "ogg": "./audio/PlayerJump.ogg"
        },
        {
            "name": "PlayerLand",
            "mp3": "./audio/PlayerLand.mp3",
            "ogg": "./audio/PlayerLand.ogg"
        },
        {
            "name": "PlayerWalk",
            "mp3": "./audio/PlayerWalk.mp3",
            "ogg": "./audio/PlayerWalk.ogg"
        },
        {
            "name": "SwitchPush",
            "mp3": "./audio/SwitchPush.mp3",
            "ogg": "./audio/SwitchPush.ogg"
        }
    ],
    "animations": [
        {
            "name": "playerIdle",
            "path": "./assets/FoxIdle1/",
            "framerate": 8,
            "frames": [
                "./assets/FoxIdle1/0.png",
                "./assets/FoxIdle1/1.png",
                "./assets/FoxIdle1/2.png",
                "./assets/FoxIdle1/3.png",
                "./assets/FoxIdle1/4.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "playerRun",
            "path": "./assets/FoxRun/",
            "framerate": 10,
            "frames": [
                "./assets/FoxRun/0.png",
                "./assets/FoxRun/1.png",
                "./assets/FoxRun/2.png",
                "./assets/FoxRun/3.png",
                "./assets/FoxRun/4.png",
                "./assets/FoxRun/5.png",
                "./assets/FoxRun/6.png",
                "./assets/FoxRun/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "playerJump",
            "path": "./assets/FoxJump/Up/",
            "framerate": 8,
            "frames": [
                "./assets/FoxJump/Up/3.png",
                "./assets/FoxJump/Up/4.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerLand",
            "path": "./assets/FoxJump/Down/",
            "framerate": 8,
            "frames": [
                "./assets/FoxJump/Down/0.png",
                "./assets/FoxJump/Down/1.png",
                "./assets/FoxJump/Down/2.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerDamage",
            "path": "./assets/FoxDamage/",
            "framerate": 8,
            "frames": [
                "./assets/FoxDamage/0.png",
                "./assets/FoxDamage/1.png",
                "./assets/FoxDamage/2.png",
                "./assets/FoxDamage/3.png",
                "./assets/FoxDamage/4.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "playerDeath",
            "path": "./assets/FoxDeath/",
            "framerate": 4,
            "frames": [
                "./assets/FoxDeath/0.png",
                "./assets/FoxDeath/1.png",
                "./assets/FoxDeath/2.png",
                "./assets/FoxDeath/3.png",
                "./assets/FoxDeath/4.png",
                "./assets/FoxDeath/5.png",
                "./assets/FoxDeath/6.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "porcupineMove",
            "path": "./assets/PorcupineMove/",
            "framerate": 4,
            "frames": [
                "./assets/PorcupineMove/0.png",
                "./assets/PorcupineMove/1.png",
                "./assets/PorcupineMove/2.png",
                "./assets/PorcupineMove/3.png",
                "./assets/PorcupineMove/4.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "porcupineDeath",
            "path": "./assets/PorcupineDeath/",
            "framerate": 4,
            "frames": [
                "./assets/PorcupineDeath/0.png",
                "./assets/PorcupineDeath/1.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "starCreatureMove",
            "path": "./assets/StarCreatureMove/",
            "framerate": 8,
            "frames": [
                "./assets/StarCreatureMove/0.png",
                "./assets/StarCreatureMove/1.png",
                "./assets/StarCreatureMove/2.png",
                "./assets/StarCreatureMove/3.png",
                "./assets/StarCreatureMove/4.png",
                "./assets/StarCreatureMove/5.png",
                "./assets/StarCreatureMove/6.png",
                "./assets/StarCreatureMove/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "starCreatureIdle",
            "path": "./assets/StarCreatureIdle/",
            "framerate": 8,
            "frames": [
                "./assets/StarCreatureIdle/0.png",
                "./assets/StarCreatureIdle/1.png",
                "./assets/StarCreatureIdle/2.png",
                "./assets/StarCreatureIdle/3.png",
                "./assets/StarCreatureIdle/4.png",
                "./assets/StarCreatureIdle/5.png",
                "./assets/StarCreatureIdle/6.png",
                "./assets/StarCreatureIdle/7.png"
            ],
            "repeatValue": -1
        },
        {
            "name": "starCreatureCharge",
            "path": "./assets/StarCreatureCharge/",
            "framerate": 16,
            "frames": [
                "./assets/StarCreatureCharge/0.png",
                "./assets/StarCreatureCharge/1.png",
                "./assets/StarCreatureCharge/2.png",
                "./assets/StarCreatureCharge/3.png"
            ],
            "repeatValue": 0
        },
        {
            "name": "starCreatureDeath",
            "path": "./assets/StarCreatureDeath/",
            "framerate": 6,
            "frames": [
                "./assets/StarCreatureDeath/0.png",
                "./assets/StarCreatureDeath/1.png",
                "./assets/StarCreatureDeath/2.png",
                "./assets/StarCreatureDeath/3.png",
                "./assets/StarCreatureDeath/4.png",
                "./assets/StarCreatureDeath/5.png"
            ],
            "repeatValue": 0
        }
    ],
    "platforms": [
        {
            "x1": 0,
            "y1": 680,
            "x2": 3000,
            "y2": 720,
            "texture": "ground"
        }
    ],
    "enemies": {
        "groundEnemies": [

        ],
        "patrolEnemies": [
            {
                "type": "porcupineSprite",
                "health": 1,
                "startX": 640,
                "startY": 200,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "porcupineSprite",
                "scoreGiven": 100,
                "patrolBounds": [
                    400,
                    880
                ],
                "speed": 100,
                "animations": [
                    "porcupineMove",
                    "porcupineDeath"
                ]
            }
        ]
    },
    "switches": [

    ],
    "doors": [

    ],
    "powerups": [
        {
            "type": "health+1",
            "x": 300,
            "y": 600,
            "sprite": "plusOneHealth"
        },
        {
            "type": "health+1",
            "x": 350,
            "y": 600,
            "sprite": "plusOneHealth"
        },
        {
            "type": "health+1",
            "x": 400,
            "y": 600,
            "sprite": "plusOneHealth"
        },
        {
            "type": "health+1",
            "x": 1900,
            "y": 600,
            "sprite": "plusOneHealth"
        }
    ],
    "bossDoors": [
        {
            "x": 0,
            "y": 0,
            "w": 0,
            "h": 0,
            "sprite": ""
        }
    ]
}

export const TestLevel = {
    "ID": 0,
    "name": "testLevel",
    "bossRoom": {
        "x": -10000,
        "y": -10000,
        "w": 1280,
        "h": 720,
        "boss": {
            "name": "Goblin Titan",
            "sprite": "goblinMech",
            "deathSprite": "deadMech",
            "health": 5,
            "scaleX": 2,
            "scaleY": 2,
            "scoreGiven": 10000,
            "spawnX": 0,
            "spawnY": 0,
            "projectileOdds": 75,  // Will be one over that number
            "projectileType": {
                "projectileSprite": "",
                "gravity": false,
                "speed": 100,
                "size": [100, 100]  // Width and height in pixels - will not rotate
            },
            "chargeOdds": 100
        }
    },
    "bounds": {
        "x": 0,
        "y": -100,
        "w": 10000,
        "h": 10000
    },
    "player": {
        "x": 40,
        "y": 300,
        "sprite": "FoxTest",
        "atlas": "" //if required
    },
    "switches": [
        {
            "x": 2300,
            "y": 660,
            "sprite": "button",
            "id": 0
        }
    ],
    "doors": [
        {
            "x": 2600,
            "y": 660,
            "w": 20,
            "h": -300,
            "sprite": "door",
            "id": 0
        }
    ],
    "platforms": [
        {
            "x1": 0,
            "y1": 660,
            "x2": 3000,
            "y2": 720,
            "texture": "ground"
        },
        {
            "x1": 200,
            "y1": 580,
            "x2": 400,
            "y2": 620,
            "texture": "ground"
        },
        {
            "x1": 0,
            "y1": 434,
            "x2": 200,
            "y2": 466,
            "texture": "ground"
        },
        {
            "x1": 400,
            "y1": 300,
            "x2": 880,
            "y2": 350,
            "texture": "ground"
        }
    ],
    "enemies": {
        "groundEnemies": [
            {
                "type": "goblinMech",
                "health": 3,
                "startX": 900,
                "startY": 500,
                "endX": 1200,
                "rngMove": true,
                "scaleX": 2,
                "scaleY": 2,
                "deathSprite": "deadMech",
                "scoreGiven": 1000,
                "animations": [

                ]
            }
        ],
        "patrolEnemies": [
            {
                "type": "ratfolk",
                "health": 1,
                "startX": 640,
                "startY": 200,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "deadRatfolk",
                "scoreGiven": 100,
                "patrolBounds": [
                    400,
                    880
                ],
                "speed": 100,
                "animations": [

                ]
            }
        ],
        "spawners": [
            {
                "type": "ratfolk",
                "x": 640,
                "y": 50,
                "odds": 1500,
                "sprite": "barrel",
                "patrols": true,
                "details": {
                    "health": 1,
                    "spawnX": 640,
                    "spawnY": 100,
                    "deathSprite": "deadRatfolk",
                    "scoreGiven": 50,
                    "patrolBounds": [
                        400,
                        880
                    ],
                    "speed": 100,
                    "scaleX": 1,
                    "scaleY": 1,
                    "animations": [

                    ]
                }
            }
        ]
    },
    "textures": [
        {
            "name": "FoxTest",
            "path": "./assets/FoxTest.png"
        },
        {
            "name": "goblinMech",
            "path": "./assets/GoblinMechEx.png"
        },
        {
            "name": "ground",
            "path": "./assets/platform.png"
        },
        {
            "name": "deadMech",
            "path": "./assets/DeadMech.png"
        },
        {
            "name": "ratfolk",
            "path": "./assets/Ratfolk.png"
        },
        {
            "name": "deadRatfolk",
            "path": "./assets/DeadRatfolk.png"
        },
        {
            "name": "barrel",
            "path": "./assets/barrel.png"
        },
        {
            "name": "button",
            "path": "./assets/buttonTemp.png"
        },
        {
            "name": "door",
            "path": "./assets/door.png"
        },
        {
            "name":"heartPU",
            "path": "./assets/heartPU.png"
        }
    ]
}

export const Template = {
    "ID": 0,
    "name": "",
    "bounds": {
        "x": 0,
        "y": 0,
        "w": 0,
        "h": 0
    },
    "player": {
        "x": 0,
        "y": 0,
        "sprite": "",
        "atlas": "",
        "deathSprite": ""
    },
    "goalItem": {
        "x": 0,
        "y": 0,
        "sprite": "",
        "nextLevel": ""
    },
    "switches": [
        {
            "x": 0,
            "y": 0,
            "sprite": "",
            "id": 0
        }
    ],
    "doors": [
        {
            "x": 0,
            "y": 0,
            "w": 0,
            "h": -0, // negative to make it go up, positive to make it go down
            "sprite": "",
            "id": 0
        }
    ],
    "bossDoors": [
        {
            "x": 0,
            "y": 0,
            "w": 0,
            "h": 0,
            "sprite": ""
        }
    ],
    "platforms": [
        {
            "x1": 0,
            "y1": 0,
            "x2": 0,
            "y2": 0,
            "texture": ""
        }
    ],
    "enemies": {
        "groundEnemies": [
            {
                "type": "",
                "health": 1,
                "startX": 0,
                "startY": 0,
                "endX": 0,
                "rngMove": true,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "",
                "scoreGiven": 0,
                "animations": [
                    "",
                    ""
                ]
            }
        ],
        "patrolEnemies": [
            {
                "type": "",
                "health": 1,
                "startX": 0,
                "startY": 0,
                "scaleX": 1,
                "scaleY": 1,
                "deathSprite": "",
                "scoreGiven": 0,
                "patrolBounds": [
                    0,
                    0
                ],
                "speed": 100,
                "animations": [
                    "",
                    ""
                ]
            }
        ],
        "spawners": [
            {
                "type": "", // mob type, e.g. ratfolk - will be the sprite too
                "x": 0,
                "y": 0,
                "odds": 0,
                "sprite": "barrel",
                "patrols": true,
                "details": { // enemy details
                    "health": 1,
                    "spawnX": 0,
                    "spawnY": 0,
                    "deathSprite": "",
                    "scoreGiven": 0,
                    "patrolBounds": [
                        0,
                        0
                    ],
                    "speed": 100,
                    "scaleX": 1,
                    "scaleY": 1,
                    "animations": [
                        "",
                        ""
                    ]
                }
            }
        ]
    },
    "textures": [
        {
            "name":"",
            "path":""
        }
    ],
    "animations": [
        {
            "name": "",
            "path": "./assets/folderName/",
            "framerate": 1,
            "frames": [
                "",
                ""  // path to all frames
            ],
            "repeatValue": -1  // repeats if -1
        }
    ],
    "powerups": [
        {
           "type":"",
           "x":0,
           "y":0,
           "sprite":""
        }
    ]
}