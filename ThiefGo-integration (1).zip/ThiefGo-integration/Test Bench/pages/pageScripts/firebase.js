// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBtyXGtRFVMSDZO77gAlMxeCsmS8n1I3_c",
    authDomain: "thief-go-23be5.firebaseapp.com",
    projectId: "thief-go-23be5",
    storageBucket: "thief-go-23be5.appspot.com",
    messagingSenderId: "132029573509",
    appId: "1:132029573509:web:7c8a1f772c161ba7513cec",
    measurementId: "G-32PC612R1W"
  };

  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

