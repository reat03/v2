const logoutButton = document.querySelector('#logout');
logoutButton.addEventListener('click', () => {
firebase.auth().signOut().then(() => {
window.location.replace('login');
});
});

var email;

firebase.auth().onAuthStateChanged((user) => {
if (!user) {
window.location.replace('login');
} else {
    document.getElementById('email').innerHTML = "<b>Email:</b> " + user.email;
    email = user.email;
    document.getElementById('username').innerHTML = "<b>Username:</b> " + user.username;
}
});

var deleteButtonClicks = 0;
const deleteButton = document.querySelector('#delete');
deleteButton.addEventListener('click', () => {
    if (deleteButtonClicks < 1) {
        alert("Clicking the delete button again will permanently remove your account. Make sure you are OK with that");
        deleteButtonClicks++;
    } else {
        firebase.auth().currentUser.delete();
    }
});

reauthenticate = (currentPassword) => {
    var user = firebase.auth().currentUser;
    var cred = firebase.auth.EmailAuthProvider.credential(email, currentPassword);
    return user.reauthenticateWithCredential(cred);
}

changePassword = (currentPassword, newPassword) => {
    reauthenticate(currentPassword).then(() => {
        var user = firebase.auth().currentUser;
        user.updatePassword(newPassword).then(() => {
            alert("Password updated");
        }).catch((error) => {
            console.log(error);
        });
    }).catch((error) => {
        console.log(error);
    });
}

changeEmail = (currentPassword, newEmail) => {
    reauthenticate(currentPassword).then(() => {
        var user = firebase.auth().currentUser;
        user.updateEmail(newEmail).then(() => {
            document.getElementById('email').innerHTML = "<b>Email:</b> " + newEmail;
            alert("Email updated");
        }).catch((error) => { console.log(error) });
    }).catch((error) => { console.log(error) });
}

const changePasswordForm = document.querySelector('#change-password');
changePasswordForm.addEventListener('submit', (e) => {
    e.preventDefault();

    let curPassword = changePasswordForm['curPassword'].value;
    let newPasswordOne = changePasswordForm['newPasswordOne'].value;
    let newPasswordTwo = changePasswordForm['newPasswordTwo'].value;

    if (newPasswordOne != newPasswordTwo) {
        alert("New passwords do not match");
        return;
    }

    changePassword(curPassword, newPasswordOne);
});

const changeEmailForm = document.querySelector('#change-email');
changeEmailForm.addEventListener('submit', (e) => {
    e.preventDefault();

    let newEmail = changeEmailForm['newEmail'].value;
    let curPassword = changeEmailForm['curPassword'].value;
    changeEmail(curPassword, newEmail);
});